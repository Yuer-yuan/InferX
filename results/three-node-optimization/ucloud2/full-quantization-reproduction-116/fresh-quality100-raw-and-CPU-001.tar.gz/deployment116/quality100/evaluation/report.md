# AI Infras 比赛评测报告

- 模型：`qwen38-27b`
- API：`http://127.0.0.1:18553/v1`
- 开始：2026-10-18T01:36:49.023939+00:00
- 结束：2026-10-18T01:53:31.036270+00:00
- 总体状态：**完整**

## 性能测试

ISL/OSL=8192/512（服务端口径）；并发 1/2/4/8；每档预热 8 请求，不计入正式统计。
延迟包含评测机到 API 的网络开销，不设置 TTFT/TPOT 达标门槛。

| 并发 | 状态 | 成功请求 | 错误请求 | 请求/s | 输出 token/s |
|---:|---|---:|---:|---:|---:|

| 并发 | 服务端实际输入 token 均值 | 最小 | 最大 |
|---:|---:|---:|---:|

| 并发 | 指标 | 平均 | P50 | P95 | P99 |
|---:|---|---:|---:|---:|---:|

TPOT 为每请求 `(端到端延迟 − TTFT)/(输出 token 数 − 1)` 后取百分位；不使用逐块间隔的 P95。
使用相同确定性输入及顺序，每轮请求传独立 cache_salt 避免跨档缓存复用；未通过服务器遥测独立验证缓存命中。

## IFBench 精度

EvalScope 原生评测，limit=100，eval_batch_size=13；生成参数仅覆盖 `max_tokens=32768`，其余沿用工具默认值。
状态：**完整**；预测记录数：100。

| 原生指标 | 原生分数（0–1） | 原生计数 |
|---|---:|---:|
| prompt_level_strict | 0.85 | 100 |
| inst_level_strict | 0.8559 | 111 |
| prompt_level_loose | 0.88 | 100 |
| inst_level_loose | 0.8919 | 111 |

指令级计数按指令聚合，不等同于提示词样本数；分数直接取 EvalScope 原生报告。

## 异常与证据

- 未发现完整性异常。

- [结构化汇总](summary.json)
- [环境与依赖版本](environment.json)
- [评测输入配置](configuration.json)
- 性能原生结果：`performance/c{1,2,4,8}/`；完整输入及其摘要：`performance/dataset.*`。
- 精度原生结果：`accuracy/native/`；输入配置及解析后的默认配置：`accuracy/task_config.json`、`accuracy/resolved_config.json`。

工具固定为 AIPerf 0.13.0、EvalScope 1.13.0。结果仅适用于本次模型、API 路径、样本和网络环境。
