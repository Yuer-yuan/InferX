#!/bin/bash
set -euo pipefail
test "$(hostname)" = cpod-1wjk44m2ji94
test "$(nvidia-smi --query-gpu=uuid --format=csv,noheader)" = GPU-c1c59c83-fc0a-2baf-58a5-84bd4020924c
taskroot=/workspace/InferX/framework-c4/sglang
export UV_CACHE_DIR="$taskroot/cache/uv"
export PIP_CACHE_DIR="$taskroot/cache/pip"
export TMPDIR="$taskroot/tmp"
mkdir -p "$TMPDIR"
if ! test -x "$taskroot/env/bin/python"; then
    /workspace/InferX/envs/build/bin/python -m uv venv --python /workspace/InferX/envs/build/bin/python "$taskroot/env"
fi
/workspace/InferX/envs/build/bin/python -m uv pip install --prerelease=allow --index-url https://pypi.tuna.tsinghua.edu.cn/simple --python "$taskroot/env/bin/python" 'sglang==0.5.19' 'torch==2.13.0' 'torchvision==0.28.0' 'torchaudio==2.11.0'
/workspace/InferX/envs/build/bin/python -m uv pip freeze --python "$taskroot/env/bin/python" > "$taskroot/requirements.lock.txt"
"$taskroot/env/bin/python" -c 'import importlib.metadata as m,torch; print({n:m.version(n) for n in ["sglang","sglang-kernel","torch","torchvision","torchaudio","transformers","flashinfer-python"]});print(torch.version.cuda,torch.cuda.get_device_name(),torch.cuda.get_device_capability())'
"$taskroot/env/bin/python" -m sglang.launch_server --help > "$taskroot/server-help.txt" 2>&1
