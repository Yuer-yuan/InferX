# Fit-only environment

Use Linux x86_64, Python 3.12 (actual 3.12.15), and the NVIDIA driver already required by the SM89 CUDA13.2 build. Create a separate virtualenv. Do not upgrade the serving environment.

```sh
python3.12 -m venv fit-env
fit-env/bin/python -m pip install --require-hashes --only-binary=:all: -r requirements-wheels.lock
```

The lock pins44 official PyPI wheels and recursively includes Torch CUDA extras. All44 wheel METADATA files were fetched and matched the installed metadata exactly. Wheel payloads were not downloaded during this metadata audit. A fresh installation must verify the full wheel SHA through pip. Torch's distribution version is2.13.0; its version.py reports2.13.0+cu130 and CUDA13.0. This is distinct from the standalone C++ build's CUDA13.2.51 toolkit. NumPy2.3.5, tokenizers0.22.2, pyarrow26.0.0 are the other direct roots. SGLang is not a fit dependency.

Keep the current fit settings: OPENBLAS_NUM_THREADS=8, OMP_NUM_THREADS=8; GPTQ FP64 feedback; TF32 disabled. Actual fit scripts record Torch binary/device identity. This installation recipe does not claim a newly tested fit environment; the live116 run uses the already installed, identically versioned environment.

The exact xgrammar build override is reconstructed by extracting xgrammar-official.tar.gz into a new directory, then dlpack-official.tar.gz into its3rdparty/dlpack. source-dependency-verdict.json contains both pinned official URLs/archive hashes. All283 measured source files match these archives; unused cpptrace/googletest submodules were absent and are not required by the recorded build flags.
