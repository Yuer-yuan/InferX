"""Resolve installed wheel tags to PyPI's fixed files without installing/downloading wheels."""
import pathlib,json,urllib.request,hashlib,concurrent.futures,itertools,re,time
R=pathlib.Path(__file__).resolve().parent;D=R/'official-index';D.mkdir(exist_ok=True)
installed=json.loads((R/'installed-recursive-dependencies-r2.json').read_text())['distributions']
def get(url):
 with urllib.request.urlopen(url,timeout=25) as response:return response.read()
def resolve(pair):
 name,v=pair;url=f'https://pypi.org/pypi/{name}/{v["version"]}/json'
 try:
  p=D/(name+'.json')
  if not p.exists():p.write_bytes(get(url))
  data=json.loads(p.read_text());tags=set(re.findall(r'^Tag: (.+)$',v['wheel'],re.M));candidates=[]
  for f in data['urls']:
   if not f['filename'].endswith('.whl'):continue
   py,abi,platform=f['filename'][:-4].split('-')[-3:]
   wt={'-'.join(a) for a in itertools.product(py.split('.'),abi.split('.'),platform.split('.'))}
   if tags&wt:candidates.append(f)
  assert len(candidates)==1,(name,[x['filename'] for x in candidates],sorted(tags))
  f=candidates[0];meta=D/(name+'-wheel.METADATA')
  if not meta.exists():meta.write_bytes(get(f['url']+'.metadata'))
  actual=hashlib.sha256(meta.read_bytes()).hexdigest();assert actual==v['metadata_sha256'],(name,'METADATA differs')
  return dict(name=name,version=v['version'],filename=f['filename'],url=f['url'],sha256=f['digests']['sha256'],bytes=f['size'],installed_metadata_equal=True,metadata_sha256=actual,index_url=url)
 except BaseException as e:return dict(name=name,error=repr(e),index_url=url)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(resolve,sorted(installed.items())))
(D/'recursive-wheel-resolution.json').write_text(json.dumps(rows,indent=2)+'\n')
errors=[x for x in rows if 'error' in x]
if not errors:
 (R/'requirements-wheels.lock').write_text('\n'.join(f'{r["name"]} @ {r["url"]} --hash=sha256:{r["sha256"]}' for r in rows)+'\n')
print(json.dumps(dict(packages=len(rows),errors=errors,all_installed_metadata_matched=not errors,wheels_not_downloaded=True),indent=2))
