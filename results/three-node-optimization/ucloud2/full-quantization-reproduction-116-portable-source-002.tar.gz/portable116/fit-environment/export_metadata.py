"""Metadata only: never imports torch or uses a CUDA API."""
import pathlib,json,sys,importlib.metadata as md,hashlib,subprocess
from packaging.requirements import Requirement
from packaging.markers import default_environment
from packaging.utils import canonicalize_name
roots=['torch','numpy','tokenizers','pyarrow'];todo=[(n,set()) for n in roots];seen={};extras={};done={};edges={};env=default_environment()
while todo:
 name,xs=todo.pop(0);key=canonicalize_name(name);extras[key]=extras.get(key,set())|xs
 if key in done and done[key]==extras[key]:continue
 d=md.distribution(name)
 seen[key]={'name':d.metadata['Name'],'version':d.version,'location':str(d.locate_file('')),'metadata_path':str(d._path),'requires_python':d.metadata.get('Requires-Python'),'installer':d.read_text('INSTALLER'),'direct_url':json.loads(d.read_text('direct_url.json')) if d.read_text('direct_url.json') else None,'wheel':d.read_text('WHEEL'),'metadata_sha256':hashlib.sha256(d.read_text('METADATA').encode()).hexdigest(),'requires_dist':d.requires or []}
 done[key]=set(extras[key])
 for req in d.requires or []:
  q=Requirement(req)
  if q.marker and not any(q.marker.evaluate(dict(env,extra=x)) for x in {''}|extras[key]):continue
  dep=md.distribution(q.name);assert not q.specifier or dep.version in q.specifier,(req,dep.version)
  edges[(key,req)]={'from':key,'to':canonicalize_name(q.name),'requirement':req};todo.append((q.name,set(q.extras)))
a={'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'roots':roots,'marker_environment':env,'distributions':seen,'requested_extras':{k:sorted(v) for k,v in extras.items()},'edges':list(edges.values()),'method':'importlib.metadata + packaging; recursive extras; no torch import/CUDA API'}
F=pathlib.Path('/workspace/InferX/framework-c4/sglang')
a['provenance_texts']={n:(F/n).read_text() for n in ['install.sh','install-v3-tuna.log','requirements.lock.txt']}
a['torch_version_source']=(F/'env/lib/python3.12/site-packages/torch/version.py').read_text()
X=pathlib.Path('/workspace/InferX/source/xgrammar_source-src');a['xgrammar']={}
git=next((str(p) for p in [pathlib.Path('/workspace/InferX/envs/build/bin/git'),pathlib.Path('/usr/bin/git'),pathlib.Path('/usr/local/bin/git')] if p.exists()),None)
for name,argv in [('HEAD',['git','rev-parse','HEAD']),('status',['git','status','--porcelain']),('submodules',['git','submodule','status','--recursive']),('origin',['git','remote','get-url','origin'])]:
 if git:
  p=subprocess.run([git]+argv[1:],cwd=X,capture_output=True,text=True);a['xgrammar'][name]={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 else:a['xgrammar'][name]={'unavailable':'No git executable; actual source files hashed below'}
a['xgrammar']['git_metadata']={str(p.relative_to(X)):p.read_text() for p in [X/'.git/HEAD',X/'.git/packed-refs',X/'.gitmodules'] if p.is_file()}
a['xgrammar']['files']={str(p.relative_to(X)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(X.rglob('*')) if p.is_file() and '.git' not in p.parts};a['xgrammar']['path']=str(X)
print(json.dumps(a))
