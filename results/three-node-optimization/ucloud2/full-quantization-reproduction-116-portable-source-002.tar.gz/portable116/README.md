# 116：从固定FP8重新量化并运行原评测

默认入口是 `reproduce.py`。它从完整源码新构建开始，重新捕获训练激活、重新拟合全部服务缓存，再加载新100二进制，运行原C14性能和原100题精度。包内没有旧量化权重、旧对象文件或预编译服务。`--prepare-only` 只展开和绑定源码，不编译、不访问GPU、不发推理请求。

这份可复跑入口与实际116历史控制器分开：实际首个024捕获在新要求到达前用了旧对象，随后按协调者认可的方案补新源码捕获并对实际3072文件做双边SHA核对。该先后顺序必须以运行回执为准；本包默认直接使用新源码捕获，没有该绕路。包的冻结、CPU检查或安装锁都不表示实际完整评测已经完成。

## 外部输入与安装

- Linux x86_64，独占一张SM89/48GB GPU；实测环境为修改版RTX4090、450W。驱动由宿主提供，不修改权限。
- CUDA13.2.51、GCC13.4及CMake/Ninja/运行库：按 `build-environment/` 中原安装脚本和显式conda锁建立独立build环境。CPU编译和GPU拟合可以重叠；正式性能开始前全部编译/拟合必须结束。
- Python3.12拟合环境：执行 `fit-environment/INSTALL.md`。`requirements-wheels.lock` 固定44个官方wheel URL和SHA，已展开CUDA extras；不需要安装SGLang。实际Torch发行版2.13.0、运行版本2.13.0+cu130；NumPy2.3.5、tokenizers0.22.2、PyArrow26.0.0。
- xgrammar：使用 `fit-environment/source-dependency-verdict.json` 中的固定官方归档。xgrammar commit `4546988d1cf51670a10eafb8795d37e4a2f0d833`，DLPack gitlink `bbd2f4d32427e548797929af08cfe2a9cbb3cf12`。先展开xgrammar，再把DLPack展开至 `3rdparty/dlpack`；入口会核实际283文件SHA。
- 原FP8：使用 `fp8-acquisition/fetch_fp8.py` 及其manifest获取72个内容文件，或提供逐SHA相同的已有目录。每文件revision已固定；不声称它们来自一个已知统一snapshot。`.mv/.msc` 是历史挂载元数据，不是第三方必须下载的权重。
- 原基础容器：`neroued/Qwen3.8-27B-NInfer`，revision `3526913004b1cf552cb57b88d6a5c6f5e4a89a70`，文件 `qwen3_8_27b.ninfer`，SHA256 `eec39564993d6e9c7d5e383382a760f093465c9d163ec9a1bd6b80199514bf3e`。它仍是固定下载依赖；本流程没有声称从FP8重建整个基础容器。`extract_tokenizer.py` 可从容器提取原tokenizer。
- 评测环境：原AIPerf0.13.0、EvalScope[ifbench]1.13.0、原NLTK资源。提供原安装/依赖锁，保持两个独立环境。原runner SHA为 `d80df390cf6d1d50129796b31fdd7f4d1e95d0043d3b942d47ac582118702fb0`。

下载基础容器的固定URL：

```text
https://huggingface.co/neroued/Qwen3.8-27B-NInfer/resolve/3526913004b1cf552cb57b88d6a5c6f5e4a89a70/qwen3_8_27b.ninfer
```

保留足够磁盘空间：三次新捕获、expanded诊断数组、服务缓存和四套正常build都会落盘。实际运行的起始剩余空间约293GB；这不是通用最小容量证明。失败目录不可覆盖，首次错误和实际partial必须保留。

## 运行

路径均为调用者自己的绝对路径，可包含空格。`--work-dir` 必须不存在；不要指向历史116运行目录。

```sh
python3 reproduce.py \
  --work-dir /work/new-reproduction \
  --fp8 /models/Qwen3.8-27B-FP8 \
  --model /models/qwen3_8_27b.ninfer \
  --tokenizer /models/tokenizer \
  --fit-python /envs/fit/bin/python \
  --build-env /envs/build \
  --cuda-root /usr/local/cuda-13.2 \
  --xgrammar /sources/xgrammar \
  --eval-envs /envs/evaluation \
  --tools /tools \
  --system-python /usr/bin/python3 \
  --port-base 19048
```

`--eval-envs` 下应有 `aiperf-0.13.0/`、`evalscope-1.13.0/` 和 `nltk_data/`。`--tools` 提供原runner所需工具。系统Python须支持pidfd。可追加 `--prepare-only` 先核展开结果；之后实际运行必须换一个新work目录。

`--system-python` 同时绑定捕获/构建控制器、最终服务入口和评测入口；拟合单独使用 `--fit-python`。捕获端口为base、base+2、base+3，最终C14/质量端口为base+4/base+5；`--cuda-root` 同时传到构建和最终服务的显式CUDA库路径。

入口自动把固定IFBench数据预置到新work目录的独立ModelScope缓存；可用 `--modelscope-cache` 显式指定另一个无冲突目录。Parquet SHA为 `80037e4d99c39a55c1e2e7d5a863d8d9edeb5ebe136ba8c1e849f8c015027c6a`，300行/344指令，原前100行/111指令。数据准备不评分、不发请求，不改变原EvalScope适配器。

## 固定执行链和数学

1. 正常构建完整005+已验证的GQA两屏障源码；新024在原Q4/Q5+A8轨迹、K0、禁用缓存复用下捕获所有64层的FFN输入。
2. 新025从原FP8逻辑 `FP32(E4M3 × BF16 block scale)` 重新拟合64个gate/up合并矩阵及64个down矩阵。不额外先cast成BF16。H512/G512、FP64 GPTQ、damp0.01、block128、无actorder、TF32关闭。
3. 正常构建完整026+同GQA修复；新038只启用新025，捕获全部input projection激活；新041显式拟合0..63全部64层，不硬链接旧039的两层。
4. 正常构建原9f5a父版本；输出捕获启用新025+新041，输出projection仍走原路径；新047只拟合固定47层：所有GDN层排除L0，即L1、L2及L4..62中 `L % 4 != 3`。
5. 正常构建完整100源码 `c976692d9657408308193b50772c700382a6e243d9da353165205dc5252f76a8`。实际新478服务文件和新二进制重新hash，产生独立manifest/recipe/index，不继承旧分数。
6. 同一新配方先运行原C14：128 measured+8 warmup+1 probe，cold8192/512，client14/native13/K3/KV121856。再独立运行原100题：client13/native13/K3/KV532480、自然EOS、只覆盖max_tokens32768，保留默认thinking/采样及全部空答、截断和失败。无thinking512变体。

原独立WikiText输入随包固定：训练4段、验证2段，每段8192 raw token IDs；训练选择seed20261017，验证选择seed20261018，请求seed42。六请求JSON SHA为 `f93b4d2b44c9ca642277f14c9260e64d8c95be2858b6c4e4b1db16874381481a`。每段4个T2048 chunk，每chunk取每4个token中的一个；每层训练8192行、留出4096行。留出不参与拟合。本次省去冻结产物后的重复留出大矩阵诊断，保留原GPU拟合和独立CPU256行反馈检查。

025的L31完整旧数组比较在便携版中等价替换为完整新expanded/scales SHA对固定预期；`reference-proof/` 保存常量来源和原full-array零差回执。它不需要旧020/021大数组。实际数学函数及训练主体不变；不能把SHA身份或少量算子检查当任务精度通过。

## 结果与边界

`portable-job.json` 保存实际阶段和子进程身份；`normal-builds-job.json` 保存四份正常构建状态。各fit目录保留每矩阵数值检查、冻结manifest及新packed/scales。`deployment116/` 保存独立配方、服务身份、原性能raw和原100质量raw。先检查终态/退出码，再读取原统计，不能用进程启动或文件存在推断完成。

TTFT P95≤10s、TPOT P95≤40ms须同时满足；另报吞吐、错误和实际缓存证据。质量报告原四项指标，保留所有100题。不同硬件、编译产物或新缓存必须实际测量；本包不承诺跨机SLO，也不把局部算子速度当端到端收益。
