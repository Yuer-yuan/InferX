"""CPU-only package construction. Does not alter or execute the live116 chain."""
import pathlib,json,hashlib,shutil,ast,difflib
P=pathlib.Path(__file__).resolve().parent;R=P.parent;D=P/'payload';assert not D.exists();D.mkdir()
def cp(source,target):
 target.parent.mkdir(parents=True,exist_ok=True)
 if source.is_dir():shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 else:shutil.copyfile(source,target)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['normal-builds','binding-tool','entrypoint-template','normal_builds.py']:
 cp(R/name,D/name)
for stage,names in {
 'true-int4-independent-calibration-014':['prepare.py','dataset-identity.json','train.parquet','validation.parquet','activation-identity.json','revision.json','parquet-revision.json'],
 'true-int4-calibrated-PTQ-015':['fit.py'],
 'true-int4-fp8-source-013':['prior-checkpoint-identity.json'],
 'true-int4-all-input-GPTQ-041':['fit.py','function-AST-proof.json'],
 'true-int4-all-output-GPTQ-047':['fit.py','function-AST-proof.json'],
 'true-int4-input-projections-038':['observer.cpp','build_observer.py','run_capture.py','requests.json','server-config.json'],
 'output-observer047':['observer.cpp','association.h','build_observer.py','run_capture.py','requests.json','server-config.json']}.items():
 for n in names:cp(R/stage/n,D/stage/n)
for n in ['owner.py','observer.cpp','server-config.json']:cp(R/'capture024-normal-r2'/n,D/'true-int4-all-layer-calibration-024'/n)
for n in ['fit.py','L31-reference-hashes.json']:cp(R/'portable-fit025'/n,D/'true-int4-all-layer-GPTQ-025'/n)
# Reuse precisely the validated serving-manifest helper, with no historical replay branch.
t=ast.parse((R/'stage_runner.py').read_text());parts=[]
for n in t.body:
 if isinstance(n,ast.FunctionDef) and n.name in ['sha','write','serving']:parts.append(ast.unparse(n))
text='import pathlib,json,hashlib,os\nR=pathlib.Path(__file__).resolve().parent\n'+'\n\n'.join(parts)+'\n'
text+="serving('true-int4-all-layer-GPTQ-025','FFN',range(64))\nserving('true-int4-all-input-GPTQ-041','input',range(64))\nserving('true-int4-all-output-GPTQ-047','output',[i for i in range(64) if i!=0 and i%4!=3])\n"
(D/'seal_serving.py').write_text(text)
# Same owned lifecycle and original evaluation entrypoint; source-only provenance replaces
# the historical116 late replay proof, because this default starts with fresh-source024.
old=(R/'final_evaluation.py').read_text();s=old
s=s.replace("run(['/usr/bin/python3',str(R/'stage_runner.py'),'seal047'],'seal047')","run(['/usr/bin/python3',str(R/'seal_serving.py')],'seal_fresh478')")
a=s.index(" eq=json.loads((R/'024-normal-source-input-equivalence.json').read_text())");b=s.index(" write(R/'full-fresh-fit-evidence.json',fit)",a)
s=s[:a]+''' capture=R/'true-int4-all-layer-calibration-024'
 assert json.loads((capture/'job.json').read_text())['phase']=='independent_calibration_complete_GPU_released'
 assert len(json.loads((capture/'activation-identity.json').read_text())['files'])==3072
 fit=dict(newly_fitted_serving_matrices=239,newly_fitted_payload_files=478,manifests=manifests,normal_source_capture_identity_sha256=sha(capture/'activation-identity.json'),actual_order='fresh normal source005 -> fresh024 -> fresh025 -> fresh038 -> fresh041 -> freshoutput -> fresh047',old_capture_or_cache_reused=False,FP8_full_identity_sha256=sha(R/'FP8-full-SHA.json'),tokenization_identity_sha256=sha(R/'tokenization-exact.json'),task_accuracy_inferred=False)
'''+s[b:]
s=s.replace("HF_HOME='/workspace/InferX/framework-c4/sglang/cache/quality-huggingface',HF_DATASETS_CACHE='/workspace/InferX/framework-c4/sglang/cache/quality-datasets',EVALSCOPE_CACHE='/workspace/InferX/framework-c4/sglang/cache/quality-evalscope'","HF_HOME=str(R/'download-cache/huggingface'),HF_DATASETS_CACHE=str(R/'download-cache/datasets'),EVALSCOPE_CACHE=str(R/'download-cache/evalscope')")
ast.parse(s);(D/'portable_finalize.py').write_text(s);(P/'portable-finalize-provenance.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True))))
cp(R/'fit-environment',P/'fit-environment')
# A frozen package is all source, corpus, expected metadata and install evidence; no binaries/caches.
bad=[str(p) for p in D.rglob('*') if p.is_file() and (p.suffix in ['.o','.a','.so'] or p.name in ['packed.bin','scales.f32','expanded.i8','ninfer-serve'])];assert not bad,bad
files={str(p.relative_to(P)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
(P/'MANIFEST.json').write_text(json.dumps(dict(files=files,no_prebuilt_objects=True,no_old_weight_caches=True,default_source_only=True),indent=2)+'\n')
print(json.dumps(dict(files=len(files),bytes=sum(v['bytes'] for v in files.values()),entry_sha256=sha(P/'reproduce.py'),manifest_sha256=sha(P/'MANIFEST.json'))))
