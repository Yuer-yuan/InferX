#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,struct
p=argparse.ArgumentParser();p.add_argument('--model',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True)
a=p.parse_args();r=pathlib.Path(__file__).resolve().parent
expected=json.loads((r/'original-support/submission/model-manifest.json').read_text())['final_tokenizer']['files']
a.out.mkdir(parents=True,exist_ok=False)
with a.model.open('rb') as f:
    magic,size=struct.unpack('<8sQ',f.read(16));assert magic==b'NINFER\x00\x02' and 0<size<32*1024**2
    directory=json.loads(f.read(size));payload=((16+size+4095)//4096)*4096
    for item in expected:
        obj=next(x for x in directory['objects'] if x['name']==item['resource'])
        assert obj['kind']=='resource' and obj['encoding']=='raw-bytes-v1'
        assert obj['bytes']==item['bytes'] and obj['offset']>=0
        assert payload+obj['offset']+obj['bytes']<=a.model.stat().st_size
        f.seek(payload+obj['offset']);b=f.read(obj['bytes']);assert hashlib.sha256(b).hexdigest()==item['sha256']
        (a.out/pathlib.Path(obj['name']).name).write_bytes(b)
print(json.dumps({'files':len(expected),'all_sha_pass':True}))
