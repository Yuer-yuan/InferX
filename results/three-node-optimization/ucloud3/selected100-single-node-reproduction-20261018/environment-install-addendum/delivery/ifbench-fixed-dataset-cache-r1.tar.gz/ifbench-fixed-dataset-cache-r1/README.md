# IFBench fixed data and original-adapter cache preparation

This is data preparation only: no model request, scoring, runner change, or sample selection.

Dataset: `allenai/IFBench_test`, subset `default`, split `train`. The included original public Parquet contains **300 rows / 344 instructions**. The original runner's first 100 rows contain **111 instructions**. Order, key, prompt, kwargs (including nulls), and instruction IDs are unchanged.

The Parquet is 94,446 bytes, SHA256:

```
80037e4d99c39a55c1e2e7d5a863d8d9edeb5ebe136ba8c1e849f8c015027c6a
```

We downloaded it independently from two fixed official revisions; their bytes are identical:

- ModelScope: `cf340e885a36d4b7b02692ddb7da242ea2643f4e`
- Hugging Face: `2e8a48de45ff3bf41242f927254ca81b59ca3ae2`

**These are content-equivalent fixed acquisition revisions. The historical loaded cache revision was not recorded and remains `null`; we do not claim to have recovered it.** All 300 records match the preserved historical corpus. The first 100 match both historical run 105's actual adapter inputs and u3 reproduction quality002's actual prediction metadata. See `identity.json` and `content-and-cohort-review.json`.

## Prepare the cache without changing the original runner

Use the same ModelScope cache root as the evaluation process. The selected100 portable owner sets it to `<RUN>/cache/modelscope`, overriding any different shell value. Set the following path to the actual **fresh** reproduction run directory before launching that owner:

```sh
INFERX_RUN=/absolute/path/to/fresh-reproduction-run
export MODELSCOPE_CACHE="$INFERX_RUN/cache/modelscope"
python3 stage_ifbench.py \
  --cache-root "$MODELSCOPE_CACHE" \
  --receipt "$INFERX_RUN/ifbench-stage-receipt.json"
```

The default command uses the included public data and requires no network. It verifies the full SHA before publication. It creates:

```
<MODELSCOPE_CACHE>/datasets/allenai--IFBench_test/snapshots/
  cf340e885a36d4b7b02692ddb7da242ea2643f4e/data/train-00000-of-00001.parquet
```

It refuses conflicting snapshots, legacy caches, symlinks, or different existing content, leaving them intact. Use a fresh run/cache root in that case. Identical existing staged content is verified and reused; use a new receipt filename. Prepare before evaluation, without another downloader writing the same cache.

This matches **ModelScope 1.40.2 / modelscope-hub 0.4.6**. The original **EvalScope 1.13.0** `DatasetHub._load_modelscope` first calls the SDK's `snapshot_download(..., local_files_only=True)`. With no revision specified and exactly one cached snapshot, the SDK resolves that snapshot. No `master` alias, fabricated revision, or modification of the original runner is needed. Dataset name and original `limit:100` remain unchanged.

Only the original Parquet is needed in the SDK snapshot. The dataset card is preserved separately as `UPSTREAM-DATASET-CARD.md`; the remote `dataset_infos.json` is not needed for this standard Parquet loader. The staged directory is a minimal data snapshot, not a claim that every repository metadata file was downloaded.

## CPU check before the model run

In the **existing pinned evaluation environment** (EvalScope 1.13.0, ModelScope 1.40.2, modelscope-hub 0.4.6, datasets 4.8.4, PyArrow 26.0.0):

```sh
python3 check_offline_cache.py \
  --cache-root "$MODELSCOPE_CACHE" \
  --receipt "$INFERX_RUN/ifbench-original-loader-check.json" \
  --evalscope
```

This invokes the original dataset loader only, checks all 300 ordered canonical record hashes and 100/111 counts, and sends **zero inference requests**. Then run the original evaluation entrypoint unchanged, with the same cache root. This helper does not score predictions or set generation parameters.

`SDK-real-offline-load.json` records our successful local real SDK + datasets offline test. It does **not** claim that EvalScope itself was imported in that local test. The `--evalscope` command is provided for the complete pinned evaluation environment. No full evaluation dependency install is required merely to stage the data.

## Fetch directly instead of using the included copy

The following downloads the fixed official ModelScope file and enforces the same SHA before staging:

```sh
python3 stage_ifbench.py --fetch modelscope \
  --cache-root "$MODELSCOPE_CACHE" \
  --receipt "$INFERX_RUN/ifbench-download-stage-receipt.json"
```

Use `--fetch huggingface` for the independently verified fixed mirror. Exact URLs are embedded in the script and preserved in the fetch receipts. Neither command reads a floating branch.

Source/license: see `LICENSE-NOTICE.md` and the unmodified upstream dataset card. This package redistributes public evaluation inputs, not predictions or model weights.
