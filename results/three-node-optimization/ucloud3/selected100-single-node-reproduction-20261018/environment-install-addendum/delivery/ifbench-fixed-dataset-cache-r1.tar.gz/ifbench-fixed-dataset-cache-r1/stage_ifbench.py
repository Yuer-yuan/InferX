#!/usr/bin/env python3
"""Preseed one immutable IFBench snapshot; no inference, scoring, or SDK edits."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import urllib.request

REPO = 'allenai/IFBench_test'
REV = 'cf340e885a36d4b7b02692ddb7da242ea2643f4e'
SHA = '80037e4d99c39a55c1e2e7d5a863d8d9edeb5ebe136ba8c1e849f8c015027c6a'
SIZE = 94446
REL = 'data/train-00000-of-00001.parquet'
URLS = {
    'modelscope': f'https://modelscope.cn/api/v1/datasets/{REPO}/repo?Revision={REV}&FilePath={REL}',
    'huggingface': f'https://huggingface.co/datasets/{REPO}/resolve/2e8a48de45ff3bf41242f927254ca81b59ca3ae2/{REL}',
}


def digest(b):
    return hashlib.sha256(b).hexdigest()


def stage(root, payload):
    assert len(payload) == SIZE and digest(payload) == SHA, 'Public parquet size/SHA mismatch'
    root = root.expanduser().resolve()
    # The SDK checks these legacy directories before its versioned snapshots.
    for p in (root / 'datasets/allenai/IFBench_test', root / 'hub/datasets/allenai/IFBench_test'):
        if p.is_symlink() or (p.exists() and (not p.is_dir() or any(p.iterdir()))):
            raise RuntimeError(f'Existing legacy cache would shadow pinned snapshot: {p}; choose a fresh cache root')
    parent = root / 'datasets'
    parent.mkdir(parents=True, exist_ok=True)
    repo = parent / 'allenai--IFBench_test'
    target = repo / 'snapshots' / REV / REL
    if repo.exists() or repo.is_symlink():
        expected = {Path('snapshots'), Path('snapshots') / REV,
                    Path('snapshots') / REV / 'data', Path('snapshots') / REV / REL}
        actual = {p.relative_to(repo) for p in repo.rglob('*')}
        if repo.is_symlink() or actual != expected or any(p.is_symlink() for p in repo.rglob('*')):
            raise RuntimeError(f'Existing cache is not this exact one-snapshot layout: {repo}; left unchanged')
        if digest(target.read_bytes()) != SHA:
            raise RuntimeError(f'Existing parquet differs: {target}; left unchanged')
        action = 'verified_existing'
    else:
        # Publish the whole repository only once all bytes are present and verified.
        tmp = Path(tempfile.mkdtemp(prefix='.ifbench-pinned-', dir=parent))
        staged = tmp / 'snapshots' / REV / REL
        staged.parent.mkdir(parents=True)
        with staged.open('xb') as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        assert digest(staged.read_bytes()) == SHA
        os.rename(tmp, repo)
        action = 'created'
    return dict(action=action, dataset=REPO, revision=REV, historical_loaded_revision=None,
                revision_meaning='public fixed revision with proven identical content; not recovered historical load revision',
                cache_root=str(root), snapshot=str(target.parent.parent), parquet=str(target),
                parquet_sha256=SHA, parquet_bytes=SIZE, network_required_for_original_loader=False,
                snapshot_layout_sdk='modelscope 1.40.2 / modelscope-hub 0.4.6',
                only_snapshot=True, runner_unchanged=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache-root', type=Path, required=True,
                   help='Use the SAME MODELSCOPE_CACHE as the unchanged evaluation process')
    p.add_argument('--fetch', choices=sorted(URLS), help='Otherwise use included, SHA-verified public parquet')
    p.add_argument('--receipt', type=Path, required=True)
    args = p.parse_args()
    if args.receipt.exists() or args.receipt.is_symlink():
        raise RuntimeError('Receipt already exists; choose a new path')
    if args.fetch:
        with urllib.request.urlopen(URLS[args.fetch], timeout=120) as r:
            payload = r.read(SIZE + 1)
    else:
        payload = (Path(__file__).resolve().parent / 'data' / 'train-00000-of-00001.parquet').read_bytes()
    result = stage(args.cache_root, payload)
    result['source'] = URLS[args.fetch] if args.fetch else 'included public parquet; no network'
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    with args.receipt.open('x') as f:
        json.dump(result, f, indent=2)
        f.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
