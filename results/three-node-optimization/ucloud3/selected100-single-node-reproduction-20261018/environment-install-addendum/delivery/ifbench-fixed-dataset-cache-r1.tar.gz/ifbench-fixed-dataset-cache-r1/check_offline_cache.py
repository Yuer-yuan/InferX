#!/usr/bin/env python3
"""CPU-only real SDK load; --evalscope also checks the unchanged original loader."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--cache-root', type=Path, required=True)
p.add_argument('--receipt', type=Path, required=True)
p.add_argument('--evalscope', action='store_true')
a = p.parse_args()
assert not a.receipt.exists()
root = a.cache_root.expanduser().resolve()
os.environ['MODELSCOPE_CACHE'] = str(root)
os.environ['HF_DATASETS_OFFLINE'] = '1'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['HF_DATASETS_CACHE'] = str(root / 'arrow-cpu-check')
from modelscope import snapshot_download
import datasets
from stage_ifbench import REPO, REV, SHA, REL

versions = {k: importlib.metadata.version(k) for k in ('modelscope', 'modelscope-hub', 'datasets', 'pyarrow')}
assert versions['modelscope'] == '1.40.2' and versions['modelscope-hub'] == '0.4.6'
assert versions['datasets'] == '4.8.4' and versions['pyarrow'] == '26.0.0'
expected = root / 'datasets/allenai--IFBench_test/snapshots' / REV
resolved = Path(snapshot_download(repo_id=REPO, repo_type='dataset', local_files_only=True)).resolve()
assert resolved == expected
assert hashlib.sha256((resolved / REL).read_bytes()).hexdigest() == SHA
if a.evalscope:
    assert importlib.metadata.version('evalscope') == '1.13.0'
    from evalscope.api.dataset.hub import DatasetHub
    rows = DatasetHub(data_id_or_path=REPO, data_source='modelscope').load('train', 'default').to_list()
    load_path = 'unmodified evalscope.api.dataset.hub.DatasetHub -> ModelScope offline snapshot -> datasets'
else:
    rows = datasets.load_dataset(str(resolved), split='train').to_list()
    load_path = 'real ModelScope offline snapshot + real datasets; EvalScope import not exercised'
assert len(rows) == 300 and len({r['key'] for r in rows}) == 300
assert sum(len(r['instruction_id_list']) for r in rows) == 344
assert sum(len(r['instruction_id_list']) for r in rows[:100]) == 111
canon = lambda r: json.dumps(r, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
sequence = [hashlib.sha256(canon(r)).hexdigest() for r in rows]
frozen = json.loads((Path(__file__).parent / 'identity.json').read_text())
assert sequence == frozen['canonical_record_sha256_ordered300']
result = dict(status='PASS', versions=versions, snapshot=str(resolved), load_path=load_path,
              all300_rows_exact=True, first100_rows_exact=True, first100_instructions=111,
              original_runner_or_scorer_changed=False, inference_requests=0, scored_predictions=0)
with a.receipt.open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps(result, indent=2))
