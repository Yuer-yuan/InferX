# Frozen100: clean build and portable single-node reproduction

This kit contains the complete 1023-file engine source (`c976692d9657408308193b50772c700382a6e243d9da353165205dc5252f76a8`), portable entrypoints, original runner/data, exact asset manifests and build/deployment scripts. It contains no model weights, quantized caches, installed Python environments or old executable. The actual u3 reproduction independently rebuilt the engine as `664cfbb989da8de5aaf58b755ecb68717a966c6992a3e377a8b04e2b2f1f7518`; a future build may have a different SHA and must be evaluated under its own identity.

Use a new empty deployment directory. Commands below run from the unpacked kit root (`$PWD`), with no SSH alias, temporary agent, `/tmp` file or previous experiment owner required. Source and entrypoint checksums are listed in the kit `MANIFEST.json`; run `sha256sum -c SHA256SUMS` before building. Generated build/deployment records use new identities after this initial package check. The exact executed u3 commands/identities are under `evidence/`.

## External prerequisites

The measured host has a 48GB RTX4090-class SM89 GPU at 450W, CUDA13.2.51 at `/usr/local/cuda-13.2`, GCC13.4/CMake/Ninja plus FFmpeg/libcurl at `/workspace/InferX/envs/build`, and XGrammar source v0.2.5.post1 at `/workspace/InferX/source/xgrammar_source-src`. Install these paths, or adapt the explicit compiler/prefix/source paths in `build_owner.py` and refreeze its controller SHA before using a different toolchain. `evidence/build-conda-explicit.lock` is the installable133-package @EXPLICIT URL/MD5 lock from the actual u3 environment (the old `.txt` is only raw command output); `evidence/actual-xgrammar-manifest.json` gives actual external source content hashes. The package does not silently install or substitute a toolchain. Acquire the pinned external source with `git clone https://github.com/mlc-ai/xgrammar.git /workspace/InferX/source/xgrammar_source-src` and `git -C /workspace/InferX/source/xgrammar_source-src checkout 4546988d1cf51670a10eafb8795d37e4a2f0d833`; retain its content manifest alongside the build. CUDA/driver installation remains an explicit host prerequisite.

For a new environment, create the build prefix with `micromamba create -p /workspace/InferX/envs/build -f evidence/build-conda-explicit.lock`. The lock already supplies packaging26.3; do not replay the build-pip-freeze local `packaging @ file:///...` path. Other original pip freezes and install scripts are under `asset-origin/remote-provenance/dependency-locks/` and `asset-origin/original-support/`. This is a recorded dependency recipe; this run reused and verified the installed environments rather than freshly installing them.

Model: `neroued/Qwen3.8-27B-NInfer`, revision `3526913004b1cf552cb57b88d6a5c6f5e4a89a70`, file `qwen3_8_27b.ninfer`, 18,210,531,328 bytes, SHA `eec39564993d6e9c7d5e383382a760f093465c9d163ec9a1bd6b80199514bf3e`.

```sh
hf download neroued/Qwen3.8-27B-NInfer qwen3_8_27b.ninfer \
  --revision 3526913004b1cf552cb57b88d6a5c6f5e4a89a70 --local-dir /your/model-directory
```

Provide the tokenizer, original025 FFN cache (256 files),041 input cache (128 files),047 selected output cache (94 files), and AIPerf0.13.0/EvalScope1.13.0 Python3.12 environments with the required NLTK resources. Exactly 478 serving weight files/12,081,971,200 bytes are specified by `entrypoint/candidate_recipes/assets-u3-47.json`. Edit `asset-sources.json` to explicitly map these assets/environments to their current locations. The checked-in map records actual u3 sources; these are data locations, not implicit prerequisites at an undocumented experiment path. Exact package versions and tokenizer contents are in `evidence/actual-evaluation-environments.json` and `evidence/actual-tokenizer-manifest.json`.

The measured run reused existing model/cache/tool environments read-only and independently rehashed all model/cache bytes. It did not re-quantize FP8 weights or install a clean OS. Weight-production provenance and rebuilding steps are separate from this serving reproduction; preserve that distinction. The complete u1 acquisition/calibration handoff is `asset-origin/handoff-recipe.tar.gz` (SHA dbdef4d812d8d30ea5395373515b0245ba4eb021f633033db2bde82e191dce14). Extract it into a new directory to obtain `selected100-reproduction/README.md`, fixed per-file FP8 download metadata, original calibration scripts and observer-parent source. `asset-origin/README.md` identifies the exact478-cache archive (12,082,360,320B, SHA a8936aa7d39e9f971256a30b415f6f271f4f70418d0705233c0c84bfabfc3fb7) and its explicit acquisition path. Original source data/reference-array limitations are retained; the archive is measured input data, not evidence of a fresh quantization run.

## Build, verify and bind the actual binary

```sh
python3 prepare_assets.py
python3 build_owner.py
python3 bind_rebuilt_recipe.py
python3 -B -m unittest discover -s entrypoint/tests -p 'test_*.py' -v
```

`prepare_assets.py` creates a clear local `assets/`, `envs/build`, `eval-envs`, `tools` and `cache/modelscope` layout via explicit symlinks, validates all model and478 cache SHA values, and checks both evaluation environments. It never writes model/cache files. `build_owner.py` performs normal clean CMake/Ninja Release/SM89 compilation, seven registered scheduler CPU tests, before/after source hashes and all55 dynamic library identities. No copied object files or old executable are used. `bind_rebuilt_recipe.py` adds a new catalogue-locked recipe bound to that actual binary, preserving the original e4ed recipes. New results start unmeasured.

## C14 performance

Terminal 1:

```sh
python3 -B entrypoint/serve_candidate.py \
  --recipe entrypoint/candidate_recipes/100-k3-u3-47-rebuilt-20261018.json \
  --profile perf-c14 --root "$PWD" --port 18540 --log-dir "$PWD/service-c14-001"
```

Terminal 2, from the same kit root:

```sh
OPENAI_API_KEY=EMPTY python3 -B entrypoint/perf_candidate.py \
  --recipe entrypoint/candidate_recipes/100-k3-u3-47-rebuilt-20261018.json \
  --concurrency 14 --root "$PWD" --service-launch "$PWD/service-c14-001/launch.json" \
  --base-url http://127.0.0.1:18540/v1 --output-dir "$PWD/performance-c14-001"
```

The fixed profile uses client14/native13/KV121856, K3, PF2048, the same19 flags, original128+8warm+1probe, original salt and 8192/512 measured token lengths. All admission delay remains in TTFT, and initial measured requests are retained. SLO is TTFT P95≤10s and TPOT P95≤40ms. The original parser emits verified metrics; apply these thresholds to `summary.json` rather than interpreting its absent `meets_slo` key.

Stop only this foreground service normally (Ctrl+C) and confirm it has exited before starting quality. Do not overlap the two services on one GPU.

## Original100 quality

Terminal 1:

```sh
python3 -B entrypoint/serve_candidate.py \
  --recipe entrypoint/candidate_recipes/100-k3-u3-47-rebuilt-20261018.json \
  --profile quality100 --root "$PWD" --port 18541 --log-dir "$PWD/service-quality-001"
```

Terminal 2:

```sh
OPENAI_API_KEY=EMPTY python3 -B entrypoint/accuracy_candidate.py \
  --recipe entrypoint/candidate_recipes/100-k3-u3-47-rebuilt-20261018.json \
  --root "$PWD" --service-launch "$PWD/service-quality-001/launch.json" \
  --base-url http://127.0.0.1:18541/v1 --output-dir "$PWD/quality100-001"
```

Quality is a separate native/client13/KV532480 service: original first100 IFBench, max_tokens32768, naturalEOS/default thinking and sampling. Both evaluator entrypoints verify the exact local service, then wait for read-only `/models` readiness before the unchanged original runner. This avoids the actual first-attempt startup timeout; no generation probe is added. Keep all100 outcomes, including empty answers, errors or length stops. Report the new binary's own scores, never historical100 quality.

The actual u3 C14 run completed with TTFT9.89641735465s, TPOT38.28584995440313ms, phase throughput304.89665937584215tokens/s,128/0errors. It is a single run, not a stability guarantee. The initial quality attempt generated0 questions and was preserved. The repaired entrypoint completed all100 original questions: prompt strict90/100, loose96/100; instruction strict100/111, loose106/111. All per-sample scores were independently recomputed with the original verifier, and actual metadata exactly matches the historical first100. There are0errors,99naturalEOS and1max_tokens32768/empty-final outcome (key88), retained in scoring. All owned processes were reaped and actual/proc absence plus GPU-empty receipts are in `evidence/`. The quality phase took1160.085s including readiness and cleanup. Complete actual raw archives and result bindings are under `evidence/`; these are this new binary's own results.

## Freshly refitted caches

The measured reproduction above deliberately enforces the original 478 cache hashes. Fresh fits have different identities and must not use or weaken that old contract. `fresh-cache-binding-tool/README.md` gives an independent CPU binder that creates a new asset manifest, immutable original 47-layer serving view, and new binary/source-bound recipe/catalogue with zero inherited quality or performance results. The generating worker must qualify fit math and native loading, then run new measurements. The binder has 14 CPU contract tests; it does not perform GPU evaluation.

For reproducible FP8 acquisition, `asset-origin/fp8-pinned-acquisition-r2/fetch_fp8.py` and its manifest pin content and revision per file. The producer tested a real config-file download and content SHA; this is not a fresh full model download. `asset-origin/selected100-base-converter-review-CPU/BASE-CONVERSION-ONE-PAGE.md` records the distinct public base-model conversion source and inputs; do not infer that base conversion or fresh quantization was executed by this serving run.

## Inspect the retained actual run

`evidence/performance-delivery.tgz` and `evidence/quality-delivery.tgz` contain the original runner outputs, predictions/reviews, native request records and owned-process receipts. Each archive includes its full raw-file SHA manifest. Extract into separate new directories to inspect them; these are historical evidence and are not input/output directories for a new run. `evidence/FINAL-SUMMARY.json` binds results to664/c976, while the initially shipped recipe catalogue deliberately retains its original identities until `bind_rebuilt_recipe.py` binds your actual new build.
