# 公共NInfer基础容器：来源与可执行重建入口

**边界已明确：公共base来自BF16；本项目025/041/047来自独立FP8输入。** 本轮恢复了原转换入口，没有下载BF16权重、执行转换或验证新容器SHA。当前116重新量化继续使用固定公开base，不受本项阻塞。此前来源包中“原作者转换入口尚未恢复”的说明由本补充证据更新；旧封包保留。

| 对象 | 固定身份 |
|---|---|
| 实际使用的公共base | `neroued/Qwen3.8-27B-NInfer@3526913004b1cf552cb57b88d6a5c6f5e4a89a70`；18,210,531,328B；SHA256 `eec39564993d6e9c7d5e383382a760f093465c9d163ec9a1bd6b80199514bf3e` |
| 原作者的BF16输入 | `Qwen/Qwen3.8-27B@1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0`；固定HF树给出18个safetensors及LFS SHA，共55,563,006,776B |
| 原转换器 | `https://github.com/Neroued/ninfer`，commit `52320554b5e71a9da96bff809ddf67ac5773ed63`；recipe `qwen3_8_27b-v1` |
| 固定ranking | `tools/freq_corpus/fixtures/ranking/ranking.train.counts.i64`；SHA256 `c692dc76388132c910547589b4fb4a0503fbd6ad50aaac6a509bbcb192a8afa5` |

以上base、revision、recipe与ranking由[固定发布README](https://huggingface.co/neroued/Qwen3.8-27B-NInfer/blob/3526913004b1cf552cb57b88d6a5c6f5e4a89a70/README.md)明确列出，并与本地原model-card manifest中的eec395容器一致。实际HTTP200的README/API/tree及SHA保存在本目录；没有完整发布`.conversion.json`，故原作者实际torch版本、设备、elapsed及完整argv运行回执仍未知。

**源码核对：** `original523-converter/`保存整个`tools/artifact`、`tools/convert`树及ranking，共36文件/12,208,287B，全部按官方523 Git tree的blob SHA验证。当前source100的`layouts.py/numeric.py`与523不逐字节相同，已保留差异清单；重建应使用523，不把当前100转换脚本默认当成原发布脚本。

原入口为`tools/convert/qwen3_8_27b/convert.py`（CLI仅`--model/--out/--device`）。下游`common/recipe.py:22,320`要求并检查BF16；**不能直接把挂载FP8目录传入**。转换逐对象执行固定groupwise量化/布局，生成1,124对象（1,118tensor+6resource）；不是本项目GPTQ，不需要024/038校准输入。入口的1124对象计划、六资源SHA及ranking均有启动前检查。

下面是由发布源码恢复的可执行命令，**不是已执行的原作者argv回执**：

```bash
# BF16_DIR须已按上列固定revision准备完整BF16 checkpoint及六资源。
# 可使用公开固定下载；本轮不执行该55.56GB下载。
hf download Qwen/Qwen3.8-27B \
  --revision 1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0 --local-dir "$BF16_DIR"
git clone https://github.com/Neroued/ninfer "$CONVERTER_ROOT"
git -C "$CONVERTER_ROOT" checkout 52320554b5e71a9da96bff809ddf67ac5773ed63
cd "$CONVERTER_ROOT"
# Python环境需torch/numpy/safetensors；记录新环境，原作者版本未知。
python3 -m tools.convert.qwen3_8_27b.convert \
  --model "$BF16_DIR" --out "$NEW_OUTPUT/qwen3_8_27b.ninfer" --device cuda
```

转换器写出同名`.conversion.json`，其中记录实际resolved device、源码、输入、布局和elapsed。其`pick_device`在CUDA不可用时会退回CPU，须核实际报告。可离线使用本包36文件闭包，但无`.git`时需用随包identity补充源码身份。成功结束后仍须完整SHA核对eec395及原始load验证，才能声称复建相同容器。

**成本依据而非运行承诺：** 输入权重55.563GB、输出18.211GB，至少需约73.774GB存储（另加环境/临时量）。最大词表矩阵248320×5120，其单份FP32临时量约5.086GB，另有abs/round/clamp/编码暂存；GPU/host峰值与耗时未实测，不能给可靠分钟数。源码按对象串行，不必同时GPU驻留全部BF16权重。

**校准seed补正：** 原014 `prepare.py`实际为train选择seed20261017、validation选择seed20261018、HTTP请求seed42。此前hand-off仅写20261017不完整；原脚本、六请求token IDs及整体SHA `f93b4d2b...`一直正确且未改变，见`calibration-seed-addendum.json`。
