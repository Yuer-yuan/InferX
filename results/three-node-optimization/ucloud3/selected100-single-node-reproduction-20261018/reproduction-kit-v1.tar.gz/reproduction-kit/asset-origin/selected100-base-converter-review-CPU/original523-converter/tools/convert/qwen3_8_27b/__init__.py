"""Qwen3.8-27B artifact conversion target."""

from .inventory import (
    ALIAS_SPECS,
    FORMAT_COUNTS,
    LAYOUT_COUNTS,
    LOGICAL_ROW_VIEW_SPECS,
    MODEL_ID,
    OBJECT_SPECS,
    RESOURCE_SPECS,
    TARGET_KEY,
    TENSOR_SPECS,
)

__all__ = [
    "ALIAS_SPECS",
    "FORMAT_COUNTS",
    "LAYOUT_COUNTS",
    "LOGICAL_ROW_VIEW_SPECS",
    "MODEL_ID",
    "OBJECT_SPECS",
    "RESOURCE_SPECS",
    "TARGET_KEY",
    "TENSOR_SPECS",
]
