"""NInfer offline conversion packages."""
