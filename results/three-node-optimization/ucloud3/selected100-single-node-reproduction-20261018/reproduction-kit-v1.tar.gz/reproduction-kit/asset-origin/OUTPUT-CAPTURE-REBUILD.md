# Exact original047 calibration parent

The complete1006-file parent is included in `output-capture-parent-9f5a-source.tar.gz`. All actual local source files were rehashed against its original manifest. Aggregate `9f5a575dd7e4798ef6ea1cff38f987f9267759e84fa6cf0be8b40aa762db38c5`; old actual binary `f4658e584aeac752a799ac3df951e6236ea55e4615bd69e54f820f876cd4e292`. This is the original input041+c3 parent, **not final100**.

Use the same CUDA13.2.51/GCC13.4/SM89 and dependency locks as the100 recipe. Extract into a new `$CAPTURE_PARENT`:

```bash
mkdir "$CAPTURE_PARENT"
tar -xzf output-capture-parent-9f5a-source.tar.gz -C "$CAPTURE_PARENT"
export CC="$TOOLCHAIN/bin/x86_64-conda-linux-gnu-gcc"
export CXX="$TOOLCHAIN/bin/x86_64-conda-linux-gnu-g++"
export PATH="$TOOLCHAIN/bin:$CUDA_ROOT/bin:$PATH"
export PKG_CONFIG_PATH="$TOOLCHAIN/lib/pkgconfig"
export LD_LIBRARY_PATH="$TOOLCHAIN/lib:$CUDA_ROOT/lib64"
cmake -S "$CAPTURE_PARENT/source" -B "$CAPTURE_PARENT/build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES=89 \
  -DCMAKE_CUDA_COMPILER="$CUDA_ROOT/bin/nvcc" -DCMAKE_CUDA_HOST_COMPILER="$CXX" \
  -DCMAKE_PREFIX_PATH="$TOOLCHAIN" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
  -DNINFER_BUILD_APPS=ON -DBUILD_TESTING=ON -DNINFER_BUILD_BENCHMARKS=OFF \
  -DNINFER_ENABLE_UI=OFF -DFETCHCONTENT_SOURCE_DIR_XGRAMMAR_SOURCE="$XGRAMMAR_SOURCE"
cmake --build "$CAPTURE_PARENT/build" --target ninfer-serve --parallel 4
python3 observer_commands.py --build "$CAPTURE_PARENT/build" --out "$CAPTURE_PARENT/new-commands"
python3 remote-provenance/output-capture-input041-r1/packet/build_observer.py \
  --compile-json "$CAPTURE_PARENT/new-commands/parent-compile-command.json" \
  --link-json "$CAPTURE_PARENT/new-commands/parent-link-command.json" \
  --parent-binary "$CAPTURE_PARENT/build/apps/ninfer-serve" \
  --out "$CAPTURE_PARENT/new-observer"
```

The original packet's source-freeze covers the observer, association and run controller. Keep it unchanged. Supply a separately copied `receiver-server-config-input041.json` with only fresh path bindings, especially NEW041; `--server-config` supports that external copy. Use `run_capture.py` command from QUANTIZATION-HANDOFF with NEW025, NEW041 and the newly built observer. The original hardcoded parent compile/link receipts are preserved for audit; the helper derives new paths from the new normal build and does not substitute old objects.

Parent source equivalence is established. A new compiled binary is not promised byte-identical; record its source, compile/link/library identities, startup and actual capture/raw. Original activation identity is provided for comparison. No build, GPU, or capture was executed while assembling this package.
