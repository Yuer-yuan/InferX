#!/usr/bin/env bash
set -euo pipefail
repro_root=${1:?Usage: build_source100.sh ROOT TOOLCHAIN_PREFIX CUDA_ROOT XGRAMMAR_SOURCE}
toolchain_prefix=${2:?}
cuda_root=${3:?}
xgrammar_source=${4:?}
export PATH="$toolchain_prefix/bin:$cuda_root/bin:$PATH"
export LD_LIBRARY_PATH="$toolchain_prefix/lib:$cuda_root/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PKG_CONFIG_PATH="$toolchain_prefix/lib/pkgconfig"
export CC="$toolchain_prefix/bin/x86_64-conda-linux-gnu-gcc"
export CXX="$toolchain_prefix/bin/x86_64-conda-linux-gnu-g++"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
test ! -e "$repro_root/build"
cmake -S "$repro_root/source" -B "$repro_root/build" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES=89 \
  -DCMAKE_CUDA_COMPILER="$cuda_root/bin/nvcc" -DCMAKE_CUDA_HOST_COMPILER="$CXX" \
  -DCMAKE_PREFIX_PATH="$toolchain_prefix" -DNINFER_BUILD_APPS=ON -DBUILD_TESTING=ON \
  -DNINFER_BUILD_BENCHMARKS=OFF -DNINFER_ENABLE_UI=OFF \
  -DFETCHCONTENT_SOURCE_DIR_XGRAMMAR_SOURCE="$xgrammar_source"
cmake --build "$repro_root/build" --parallel 4 --target ninfer-serve \
  ninfer_slo_bounded_decode_membership_test ninfer_slo_completion_policy_test \
  ninfer_slo_prefill_queue_policy_test ninfer_slo_budget_policy_test
ctest --test-dir "$repro_root/build" --output-on-failure \
  -R '^ninfer_slo_(bounded_decode_membership.*|completion_policy_test|prefill_queue_policy_test|budget_policy_test)$'
