#!/usr/bin/env python3
"""CPU content check; no service, calibration or GPU imports."""
import argparse, hashlib, json, pathlib
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,required=True)
p.add_argument('--manifest',type=pathlib.Path,default=pathlib.Path(__file__).with_name('assets-u3-47.json'))
a=p.parse_args();m=json.loads(a.manifest.read_text());count=total=0
for family,block in sorted(m['caches'].items()):
    base=a.root/family
    actual={str(x.relative_to(base)) for x in base.rglob('*') if x.is_file()}
    assert actual==set(block['files']), (family,'file set differs')
    for n,v in sorted(block['files'].items()):
        f=base/n;assert f.stat().st_size==v['bytes'],str(f);h=hashlib.sha256()
        with f.open('rb') as s:
            for b in iter(lambda:s.read(8<<20),b''):h.update(b)
        assert h.hexdigest()==v['sha256'],str(f)
        count+=1;total+=v['bytes']
assert count==478
print(json.dumps(dict(passed=True,files=count,bytes=total)))
