```bash
# Run from the delivered InferX repository root.
export INFERX_REPO="$PWD"
export INFERX_BUNDLE="$INFERX_REPO/results/three-node-optimization/ucloud3"
export INFERX_BUNDLE="$INFERX_BUNDLE/selected100-single-node-reproduction-20261018"
export INFERX_KIT="$INFERX_BUNDLE/reproduction-kit"
export INFERX_PROVENANCE="$INFERX_KIT/asset-origin"
export INFERX_LOCKS="$INFERX_PROVENANCE/remote-provenance/dependency-locks"
export INFERX_DEPENDENCIES=/workspace/InferX
export INFERX_MAMBA="$(command -v micromamba)"
export INFERX_CUDA_ROOT=/usr/local/cuda-13.2
mkdir -p "$INFERX_DEPENDENCIES"/{envs,eval-envs,config,cache,tools,source}

"$INFERX_MAMBA" --no-rc create --yes \
  --root-prefix "$INFERX_DEPENDENCIES/cache/mamba" \
  --prefix "$INFERX_DEPENDENCIES/envs/build" \
  --file "$INFERX_KIT/evidence/build-conda-explicit.lock"
```

```bash
# Preserve the original freeze. packaging comes from the explicit conda lock.
python3 - "$INFERX_LOCKS/build-pip-freeze.txt" \
  "$INFERX_DEPENDENCIES/config/build-pip-install.txt" <<'PY'
from pathlib import Path
import sys
lines = Path(sys.argv[1]).read_text().splitlines()
local = [line for line in lines if ' @ file:' in line]
assert len(local) == 1 and local[0].startswith('packaging @ file:///')
Path(sys.argv[2]).write_text('\n'.join(line for line in lines if line not in local) + '\n')
PY
export INFERX_BUILD_PY="$INFERX_DEPENDENCIES/envs/build/bin/python"
"$INFERX_BUILD_PY" -m pip install --no-deps \
  --index-url https://pypi.org/simple \
  -r "$INFERX_DEPENDENCIES/config/build-pip-install.txt"
"$INFERX_BUILD_PY" -c 'import packaging; assert packaging.__version__ == "26.3"'
"$INFERX_BUILD_PY" -m pip install --no-deps \
  --index-url https://pypi.org/simple uv==0.11.29
"$INFERX_DEPENDENCIES/envs/build/bin/uv" --version
"$INFERX_BUILD_PY" -m pip check

for inferx_eval_spec in aiperf:0.13.0 evalscope:1.13.0; do
  inferx_eval_name=${inferx_eval_spec%:*}
  inferx_eval_version=${inferx_eval_spec#*:}
  inferx_eval_dir="$INFERX_DEPENDENCIES/eval-envs/$inferx_eval_name-$inferx_eval_version"
  "$INFERX_BUILD_PY" -m venv "$inferx_eval_dir"
  "$inferx_eval_dir/bin/python" -m pip install \
    --index-url https://pypi.org/simple pip==26.2.1
  "$inferx_eval_dir/bin/python" -m pip install --no-deps \
    --index-url https://pypi.org/simple \
    -r "$INFERX_LOCKS/$inferx_eval_name-pip-freeze.txt"
  "$inferx_eval_dir/bin/python" -m pip check
done
```

```bash
# Download the three NLTK resources and verify their original content hashes.
python3 - \
  "$INFERX_PROVENANCE/original-support/results/ninfer-performance/preparation/nltk-resources.json" \
  "$INFERX_DEPENDENCIES/eval-envs/nltk_data" <<'PY'
from pathlib import Path
import hashlib, json, sys, urllib.request, zipfile
manifest, root = Path(sys.argv[1]), Path(sys.argv[2])
archives = root / '.archives'
archives.mkdir(parents=True, exist_ok=True)
for item in json.loads(manifest.read_text()):
    target = archives / item['file']
    if not target.exists():
        with urllib.request.urlopen(item['source'], timeout=120) as response:
            target.write_bytes(response.read())
    data = target.read_bytes()
    assert len(data) == item['bytes']
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    kind = item['source'].split('/packages/', 1)[1].split('/', 1)[0]
    with zipfile.ZipFile(target) as archive:
        archive.extractall(root / kind)
PY
export NLTK_DATA="$INFERX_DEPENDENCIES/eval-envs/nltk_data"
"$INFERX_DEPENDENCIES/eval-envs/evalscope-1.13.0/bin/python" - <<'PY'
import nltk
for resource in ('tokenizers/punkt_tab', 'corpora/stopwords',
                 'taggers/averaged_perceptron_tagger_eng'):
    print(nltk.data.find(resource))
PY
```

```bash
# Obtain the exact grammar dependency; CUDA and its driver are prerequisites.
git clone https://github.com/mlc-ai/xgrammar.git \
  "$INFERX_DEPENDENCIES/source/xgrammar_source-src"
git -C "$INFERX_DEPENDENCIES/source/xgrammar_source-src" \
  checkout 4546988d1cf51670a10eafb8795d37e4a2f0d833
git -C "$INFERX_DEPENDENCIES/source/xgrammar_source-src" \
  submodule update --init --recursive
export PATH="$INFERX_DEPENDENCIES/envs/build/bin:$INFERX_CUDA_ROOT/bin:$PATH"
export LD_LIBRARY_PATH="$INFERX_DEPENDENCIES/envs/build/lib:$INFERX_CUDA_ROOT/lib64"
"$INFERX_CUDA_ROOT/bin/nvcc" --version
"$INFERX_DEPENDENCIES/envs/build/bin/x86_64-conda-linux-gnu-g++" --version
```
