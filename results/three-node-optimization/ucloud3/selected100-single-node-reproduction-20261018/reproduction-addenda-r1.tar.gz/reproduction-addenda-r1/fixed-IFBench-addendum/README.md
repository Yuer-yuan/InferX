# Fixed IFBench data: compose with the frozen v1 deployment

This addendum supplies a pinned public dataset acquisition/cache package. It does not change the original runner, scoring, first100 order, generation parameters or frozen v1. The300 original records/344 instructions and first100/111 instructions match the actual quality002 prediction metadata. The archive has SHA256 `c267da418e8c0a79b402e37237b14fde4a17233f60b8d5f866b85493fda757aa`.

**Stage into an independent input directory first; then bind it through asset-sources.json; then run prepare_assets.py.** Do not pre-create a real `RUN/cache/modelscope` directory: the v1 preparation script must create that path as a symlink. Do not use an old populated cache which could shadow the fixed snapshot.

```sh
INFERX_RUN=/absolute/path/to/unpacked-reproduction-kit
INFERX_INPUTS=/absolute/path/to/fresh-inputs
INFERX_DATA_PACKAGE=/absolute/path/to/ifbench-fixed-dataset-cache-r1
mkdir -p "$INFERX_INPUTS"
python3 "$INFERX_DATA_PACKAGE/stage_ifbench.py" \
  --cache-root "$INFERX_INPUTS/ifbench-modelscope" \
  --receipt "$INFERX_INPUTS/ifbench-stage-receipt.json"
python3 - "$INFERX_RUN/asset-sources.json" "$INFERX_INPUTS/ifbench-modelscope" <<'PY'
from pathlib import Path
import json, sys
path = Path(sys.argv[1])
data = json.loads(path.read_text())
data['cache/modelscope'] = str(Path(sys.argv[2]).resolve(strict=True))
path.write_text(json.dumps(data, indent=2) + '\n')
PY
# Configure the other model/cache/environment paths in asset-sources.json as usual.
(cd "$INFERX_RUN" && python3 prepare_assets.py)
"$INFERX_RUN/eval-envs/evalscope-1.13.0/bin/python" \
  "$INFERX_DATA_PACKAGE/check_offline_cache.py" \
  --cache-root "$INFERX_RUN/cache/modelscope" \
  --receipt "$INFERX_RUN/ifbench-original-loader-check.json" --evalscope
```

The owner continues to set `MODELSCOPE_CACHE=RUN/cache/modelscope`; this now resolves to the one pinned input snapshot. The checker invokes the unchanged EvalScope dataset loader and verifies all300 ordered hashes and first100/111 counts without inference or scoring. Future generation still uses the original selected100 entrypoint and original limit100.

The included data is the same public Parquet independently acquired at ModelScope `cf340e885a36d4b7b02692ddb7da242ea2643f4e` and HuggingFace `2e8a48de45ff3bf41242f927254ca81b59ca3ae2`. These pins establish a reproducible equivalent-content source; the historical loaded revision was null and is not invented retrospectively. See the packaged license notice/card and full acquisition receipts.

Actual u3 CPU composition validation **passed** in the separate fresh environment-install prefix. It staged the snapshot outside a new `cpu-linkage-run`, executed the unchanged v1 `prepare_assets.py` there using explicit input/environment mappings, then used the freshly installed EvalScope through the resulting RUN cache symlink. All 300 ordered records and first 100/111 instructions matched. No inference request or score was generated. The installation addendum supplies `delivery/post-install-job.json`, `delivery/ifbench-stage-receipt.json`, `delivery/ifbench-original-EvalScope-loader-check.json`, and `delivery/cpu-linkage-run/asset-verification.json` (the latter records actual serving-cache checks). Actual model, all 478 cache files, fixed snapshot and six verifier sources were checked; this establishes CPU composition without repeating C14 or quality100.
