# Selected100 reproduction addenda r1

Use alongside the immutable `reproduction-kit-v1.tar.gz` (SHA256 `62fc432a278f2b7f8c60472c173929fc1f537ea2785908207e8b1ce7703ed545`). This archive adds actual fresh dependency installation, pinned IFBench acquisition and CPU deployment/loader composition evidence. It does not change the selected source, executable, original runner, requests, scoring, C14 result or quality100 result.

1. Follow the core kit and submitted guide using the default dependency layout `/workspace/InferX`. The guide's normal build-to-recipe route depends on those paths; arbitrary dependency-prefix support is not claimed here.
2. Follow `fixed-IFBench-addendum/README.md`: stage the fixed snapshot into independent inputs, point `asset-sources.json` at it, then run the original preparation script. This order avoids the RUN cache symlink conflict.
3. Read `environment-install-addendum/README.md` and `delivery/FINAL-SUMMARY.json` for actual installation and original-loader checks. All 27 install steps completed in 857.424 seconds. The new environment did not run the measured 664 executable; its original RPATH still selects the old measured prefix. The first comparison failure and corrected direct-file comparison are both retained.

The measured 664 C14 and quality100 results remain in the frozen core v1. The fresh environment check reused only download/extraction caches and preinstalled system CUDA/driver prerequisites, not old virtual environments. It performed no engine rebuild, GPU inference or new scoring. The pinned data CPU check matched all 300 records and first 100/111 instructions.

`MANIFEST.json` and `SHA256SUMS` cover every file in this addendum, including nested manifests and SHA256SUMS. `reproduction-kit-v1-complete-content-manifest.json` separately covers all 1212 original core-tar files, including its nested checksum files, without modifying v1.
