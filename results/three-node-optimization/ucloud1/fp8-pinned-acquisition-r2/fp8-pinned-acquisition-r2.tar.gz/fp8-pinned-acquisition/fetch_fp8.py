#!/usr/bin/env python3
"""Download fixed ModelScope revisions; require original full-file SHA256."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import urllib.parse
import urllib.request

BLOCK = 8 << 20
REPO = 'Qwen/Qwen3.8-27B-FP8'

def hash_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(BLOCK), b''):
            h.update(block)
    return h.hexdigest()

def validate_existing(path, item):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'Existing destination is not a regular file: {path}')
    if path.stat().st_size != item['bytes'] or hash_file(path) != item['sha256']:
        raise RuntimeError(f'Existing destination mismatch, left untouched: {path}')

def acquire(item, destination, timeout):
    path = destination / item['file']
    url = ('https://modelscope.cn/models/' + REPO + '/resolve/'
           + item['per_file_revision'] + '/' + urllib.parse.quote(item['file']))
    if path.exists() or path.is_symlink():
        validate_existing(path, item)
        return dict(file=item['file'], bytes=item['bytes'], sha256=item['sha256'],
                    status='verified_existing', url=url, HTTP_request=False)
    partial = path.with_name(path.name + '.partial')
    # Exclusive creation also rejects an existing partial/symlink; never overwrite.
    h = hashlib.sha256()
    size = 0
    with partial.open('xb') as out:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            if response.status != 200:
                raise RuntimeError(f'HTTP {response.status}: {url}')
            for block in iter(lambda: response.read(BLOCK), b''):
                size += len(block)
                if size > item['bytes']:
                    raise RuntimeError(f'Unexpected download length: {item["file"]}')
                h.update(block)
                out.write(block)
        if size != item['bytes'] or h.hexdigest() != item['sha256']:
            raise RuntimeError(f'Download mismatch; partial retained: {partial}')
        out.flush()
        os.fsync(out.fileno())
    # Same-directory hard link atomically publishes verified bytes, without replacing
    # a destination created by another process between the two checks.
    os.link(partial, path)
    partial.unlink()
    dfd = os.open(destination, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(dfd)
    finally:
        os.close(dfd)
    return dict(file=item['file'], bytes=size, sha256=h.hexdigest(),
                status='downloaded_verified', url=url, HTTP_request=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--manifest', type=Path,
                        default=Path(__file__).with_name('fp8-content-manifest.json'))
    parser.add_argument('--only', action='append', help='Subset only; never reports full72 completion')
    parser.add_argument('--timeout', type=float, default=180)
    parser.add_argument('--receipt', type=Path, help='New JSON file; refuses an existing receipt')
    args = parser.parse_args()
    if args.timeout <= 0:
        raise ValueError('timeout must be positive')
    raw = args.manifest.read_bytes()
    manifest = json.loads(raw)
    items = manifest['files']
    if manifest['repo'] != REPO or len(items) != 72:
        raise ValueError('Expected original Qwen FP8 72-file content manifest')
    names = set()
    for item in items:
        name = item['file']
        if (Path(name).name != name or name.startswith('.') or name in names
                or not re.fullmatch('[0-9a-f]{40}', item['per_file_revision'])
                or not re.fullmatch('[0-9a-f]{64}', item['sha256'])
                or type(item['bytes']) is not int or item['bytes'] <= 0):
            raise ValueError(f'Invalid manifest entry: {name}')
        names.add(name)
    requested = set(args.only) if args.only else names
    if not requested <= names:
        raise ValueError(f'Unknown content files: {sorted(requested - names)}')
    if args.receipt and args.receipt.exists():
        raise FileExistsError(args.receipt)
    args.directory.mkdir(parents=True, exist_ok=True)
    records = []
    started = time.time_ns()
    for item in items:
        if item['file'] in requested:
            record = acquire(item, args.directory, args.timeout)
            records.append(record)
            print(json.dumps(record), flush=True)
    receipt = dict(status='complete', full_model_content_complete=requested == names,
                   verified_files=len(records), total_content_files=72,
                   verified_bytes=sum(x['bytes'] for x in records),
                   directory=str(args.directory.resolve()),
                   manifest_sha256=hashlib.sha256(raw).hexdigest(),
                   started_ns=started, finished_ns=time.time_ns(), files=records,
                   mount_metadata_downloaded=False, pickle_used=False)
    if args.receipt:
        with args.receipt.open('x') as f:
            json.dump(receipt, f, indent=2)
            f.write('\n')
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps(dict(status='failed', error=repr(exc))), file=sys.stderr, flush=True)
        raise
