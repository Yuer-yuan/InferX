# 固定FP8输入获取入口

仅需Python3标准库（Linux）。默认获取本次重新量化所需的72个冻结内容文件，共30,879,892,015字节；每个文件使用自己的原始ModelScope revision和完整SHA256，**不是未固定的master下载**，也不声称72个文件来自同一个仓库snapshot。

```bash
python3 fetch_fp8.py \
  --directory /absolute/new/Qwen3.8-27B-FP8 \
  --receipt /absolute/new/fp8-acquisition-complete.json
```

`--directory`可迁移。脚本从固定官方前缀`https://modelscope.cn/models/Qwen/Qwen3.8-27B-FP8/resolve/<per-file-revision>/<filename>`获取，清单为旁边的`fp8-content-manifest.json`，SHA256 `60165b24fdc49b02af953ce02b9f8cd42fe7a9af00949a1138611cacc63de190`。`download-urls-and-SHA256.tsv`列出全部具体URL、字节数和SHA。

每个文件下载到独占创建的`.partial`，流式校验完整长度/SHA并fsync后，在同一目录通过不覆盖的原子hard-link发布最终文件，再移除partial。已有正确文件重新哈希后复用；已有不匹配文件、symlink、已有partial均拒绝并保留原文件。不静默覆盖、不自动换revision、不自动续传失败。成功receipt逐文件标明下载或复用，只有72文件全验证才标完整清单通过。

`.mv`和`.msc`未列入内容清单、不会下载；脚本不使用pickle。清单来自先前已核内容SHA与逐文件revision证据。72文件范围是本次FP8校准输入合同，不等于宣称下载了公开仓库全部附加文件。

本次仅执行以下有界真实验证，**没有下载30.9GB权重**：

```bash
python3 fetch_fp8.py --directory NEW_CONFIG_SMOKE \
  --only config.json --timeout 30 --receipt NEW_CONFIG_RECEIPT.json
```

结果HTTP200、51,350B，SHA `74227dd615bf1ea975aa676bdf355a0379858c12f394b5365cd9dfa5fc2c70bc`与冻结值一致；进程exit0/reaped。receipt明确1/72且`full_model_content_complete=false`。`real-config-smoke-*`保存实际命令、身份、日志和终态。CPU测试验证不匹配已有文件与已有partial均在任何HTTP请求前拒绝，源字节不变。未启动GPU/转换/量化。

这用于复验的**外部FP8输入获取**；025/041/047仍须独立执行原capture/fit并记录新产物。公共`.ninfer`来自另一固定BF16来源，不能用此下载动作冒充基础容器重建。
