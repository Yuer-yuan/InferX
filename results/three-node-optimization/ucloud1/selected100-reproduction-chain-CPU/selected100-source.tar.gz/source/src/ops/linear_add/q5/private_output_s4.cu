#include "private_output_s4.h"
#include "private_output_op.cuh"
#include "core/device.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <unordered_map>
#include <vector>
namespace ninfer::ops::detail {
namespace {
struct View { const std::uint8_t* q; const float* s; int layer; };
std::unordered_map<const void*, View> views;
std::array<bool,64> layers{};
bool begun = false, sealed = false;
void shape(const Tensor& x, int N, int T) {
    if (!x.data || x.dtype != DType::BF16 || x.ne[0] != N || x.ne[1] != T ||
        x.ne[2] != 1 || x.ne[3] != 1 || x.nb[0] != 2 || x.nb[1] != N * 2)
        throw std::runtime_error("outputS4 contiguous BF16 geometry");
}
}
bool output_s4_enabled() {
    static const bool enabled = [] {
        const char* s = std::getenv("NINFER_OUTPUT_S4");
        if (!s || !std::strcmp(s,"0")) return false;
        if (!std::strcmp(s,"1")) return true;
        throw std::runtime_error("NINFER_OUTPUT_S4 must be 0 or 1");
    }();
    return enabled;
}
void output_s4_begin() {
    if (!output_s4_enabled() || begun) throw std::runtime_error("outputS4 one model lifetime");
    begun = true; views.reserve(47);
    CUDA_CHECK(ucloud3::output_s4_op::prepare_attributes());
    (void)ninfer::device_sm_count();
}
void output_s4_load_register(const Weight& w, std::uint8_t* cache, int layer, cudaStream_t stream) {
    if (!begun || sealed || !output_s4_selected_layer(layer) || layers[layer] || !cache ||
        !w.qdata || w.qtype != QType::Q5G64_F16S || w.padded_shape[0] != 5120 ||
        w.padded_shape[1] != 6144 || reinterpret_cast<std::uintptr_t>(cache)%256)
        throw std::runtime_error("outputS4 selected original weight registration");
    const char* dir = std::getenv("NINFER_OUTPUT_S4_CACHE");
    if (!dir || !*dir) throw std::runtime_error("explicit frozen047 cache path required");
    auto read = [&](const char* name, std::size_t n) {
        auto p = std::filesystem::path(dir)/("weights-L"+std::to_string(layer)+"-output")/name;
        std::ifstream f(p,std::ios::binary|std::ios::ate);
        if (!f || f.tellg()!=std::streamoff(n)) throw std::runtime_error("outputS4 cache size "+p.string());
        std::vector<std::uint8_t> v(n); f.seekg(0); f.read(reinterpret_cast<char*>(v.data()),n);
        if (!f) throw std::runtime_error("outputS4 cache read"); return v;
    };
    auto q=read("packed.bin",output_s4_code_bytes), s=read("scales.f32",output_s4_scale_bytes);
    for (auto b:q) if ((b&15)==8 || (b>>4)==8) throw std::runtime_error("outputS4 forbidden -8 code");
    for (std::size_t i=0;i<s.size();i+=4) { float x; std::memcpy(&x,s.data()+i,4);
        if (!(x>0) || !std::isfinite(x)) throw std::runtime_error("outputS4 invalid scale"); }
    CUDA_CHECK(cudaMemcpyAsync(cache,q.data(),q.size(),cudaMemcpyHostToDevice,stream));
    CUDA_CHECK(cudaMemcpyAsync(cache+q.size(),s.data(),s.size(),cudaMemcpyHostToDevice,stream));
    CUDA_CHECK(cudaStreamSynchronize(stream));
    std::vector<std::uint8_t> check(q.size());
    CUDA_CHECK(cudaMemcpyAsync(check.data(),cache,q.size(),cudaMemcpyDeviceToHost,stream));
    CUDA_CHECK(cudaStreamSynchronize(stream));
    if (check!=q) throw std::runtime_error("outputS4 code readback");
    check.resize(s.size());
    CUDA_CHECK(cudaMemcpyAsync(check.data(),cache+q.size(),s.size(),cudaMemcpyDeviceToHost,stream));
    CUDA_CHECK(cudaStreamSynchronize(stream));
    if (check!=s) throw std::runtime_error("outputS4 scale readback");
    if (!views.emplace(w.qdata,View{cache,reinterpret_cast<const float*>(cache+q.size()),layer}).second)
        throw std::runtime_error("outputS4 duplicate original identity");
    layers[layer]=true;
    std::fprintf(stderr,"OUTPUT_S4_cache_readback layer=%d code_bytes=%zu scale_bytes=%zu bitexact=1\n",layer,q.size(),s.size());
}
void output_s4_seal() {
    if (!begun || sealed || views.size()!=47) throw std::runtime_error("outputS4 exact47 count");
    for (int i=0;i<64;++i) if (layers[i]!=output_s4_selected_layer(i))
        throw std::runtime_error("outputS4 fixed mask registration");
    sealed=true;
}
bool output_s4_registered(const Weight& w) {
    if (!output_s4_enabled()) return false;
    if (!sealed) throw std::runtime_error("outputS4 seal before runtime/Graph");
    const auto& immutable=views;
    return immutable.find(w.qdata)!=immutable.end();
}
void output_s4_launch(const Tensor& x,const Weight& w,Tensor& y,const OutputS4Scratch& q,cudaStream_t stream,bool verify_phase) {
    if (!output_s4_registered(w)) throw std::runtime_error("outputS4 unregistered launch");
    const int T=int(x.ne[1]); shape(x,6144,T); shape(y,5120,T);
    const auto& immutable=views; const auto& v=immutable.at(w.qdata);
    ucloud3::output_s4_op::launch(static_cast<const __nv_bfloat16*>(x.data),v.q,v.s,
        static_cast<__nv_bfloat16*>(y.data),{q.codes,q.code_bytes,q.scales,q.scale_bytes},
        T,ninfer::device_sm_count(),stream);
    static const bool log=std::getenv("NINFER_OUTPUT_S4_ROUTE_LOG")!=nullptr;
    if (log) std::fprintf(stderr,"OUTPUT_S4_ROUTE layer=%d phase=%s T=%d cache=%p stream=%p\n",v.layer,verify_phase?"Verify":"Prefill",T,v.q,static_cast<void*>(stream));
}
} // namespace ninfer::ops::detail
