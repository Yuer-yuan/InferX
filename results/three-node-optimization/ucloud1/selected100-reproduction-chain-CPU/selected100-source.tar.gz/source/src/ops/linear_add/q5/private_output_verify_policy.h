#pragma once
#include <cstdlib>
#include <stdexcept>
#include <string_view>
namespace ninfer::ops::detail {
// Read once before capacity planning/Graph capture. Never toggle an existing Program.
inline bool output_s4_verify_enabled() {
    static const bool enabled = [] {
        const char* value = std::getenv("NINFER_OUTPUT_S4_VERIFY");
        if (!value || std::string_view(value) == "0") return false;
        if (std::string_view(value) == "1") return true;
        throw std::invalid_argument("NINFER_OUTPUT_S4_VERIFY must be 0 or 1");
    }();
    return enabled;
}
inline constexpr bool output_s4_verify_shape(int tokens) noexcept {
    return tokens >= 33 && tokens <= 128;
}
inline constexpr int output_s4_verify_peak_tokens(int first, int last) noexcept {
    return first <= last && first <= 128 && last >= 33 ? (last < 128 ? last : 128) : 0;
}
} // namespace ninfer::ops::detail
