#pragma once
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <cstdint>

namespace ucloud2::down_h512_singlewarp053 {
// Private CPU-reviewed candidate; GPU parity/resources/performance not yet tested.
// Fixed K17408, G512, 8 complete warps/CTA, one (token, group) per warp.
// Original ownership (warp=r,lane=l,e) becomes (register=r,lane=l,e).
// Original 9 F32 butterfly levels and operand order are unchanged.
__global__ void __launch_bounds__(256) kernel(
    const __nv_bfloat16* __restrict__ x, uint8_t* __restrict__ q,
    float* __restrict__ scale, float* rotated, int T) {
  const int lane = threadIdx.x & 31;
  const int group_id = int(blockIdx.x) * 8 + (threadIdx.x >> 5);
  if (group_id >= T * 34) return;  // uniform within a whole warp
  const int t = group_id / 34, j = group_id % 34;
  float v[8][2];
#pragma unroll
  for (int r = 0; r < 8; ++r) {
    const int k = j * 512 + r * 64 + 2 * lane;
    const auto p = *reinterpret_cast<const __nv_bfloat162*>(
        x + int64_t(t) * 17408 + k);
    v[r][0] = __fadd_rn(__bfloat162float(p.x), __bfloat162float(p.y));
    v[r][1] = __fsub_rn(__bfloat162float(p.x), __bfloat162float(p.y));
#pragma unroll
    for (int off = 1; off <= 16; off *= 2) {
#pragma unroll
      for (int e = 0; e < 2; ++e) {
        const float other = __shfl_xor_sync(0xffffffffu, v[r][e], off);
        v[r][e] = (lane & off) ? __fsub_rn(other, v[r][e])
                                   : __fadd_rn(v[r][e], other);
      }
    }
  }
  // Both old operands are read into temporaries before either is overwritten.
  // Each disjoint pair occurs exactly once at each level (global strides64/128/256).
#pragma unroll
  for (int off = 1; off <= 4; off *= 2) {
#pragma unroll
    for (int r = 0; r < 8; ++r) {
      if (!(r & off)) {
#pragma unroll
        for (int e = 0; e < 2; ++e) {
          const float a = v[r][e], b = v[r ^ off][e];
          v[r][e] = __fadd_rn(a, b);
          v[r ^ off][e] = __fsub_rn(a, b);
        }
      }
    }
  }
  const float norm = __uint_as_float(0x3d3504f3u);
  float m = 0.f;
#pragma unroll
  for (int r = 0; r < 8; ++r) {
#pragma unroll
    for (int e = 0; e < 2; ++e) {
      v[r][e] = __fmul_rn(v[r][e], norm);
      m = fmaxf(m, fabsf(v[r][e]));
      if (rotated) rotated[int64_t(t) * 17408 + j * 512 + r * 64 + 2 * lane + e] = v[r][e];
    }
  }
#pragma unroll
  for (int off = 16; off; off >>= 1)
    m = fmaxf(m, __shfl_xor_sync(0xffffffffu, m, off));
  const float inv = m > 0.f ? __fdiv_rn(7.f, m) : 0.f;
  if (lane == 0) scale[group_id] = m > 0.f ? __fdiv_rn(m, 7.f) : 0.f;
#pragma unroll
  for (int r = 0; r < 8; ++r) {
    const int a = max(-7, min(7, __float2int_rn(__fmul_rn(v[r][0], inv))));
    const int b = max(-7, min(7, __float2int_rn(__fmul_rn(v[r][1], inv))));
    q[int64_t(t) * 8704 + j * 256 + r * 32 + lane] =
        uint8_t((a & 15) | ((b & 15) << 4));
  }
}
// Future caller: kernel<<<(T*34+7)/8,256,0,stream>>>(x,q,scale,rotated,T).
// Production rotated=nullptr; debug stores the same original normalized F32 values.
}  // namespace ucloud2::down_h512_singlewarp053
