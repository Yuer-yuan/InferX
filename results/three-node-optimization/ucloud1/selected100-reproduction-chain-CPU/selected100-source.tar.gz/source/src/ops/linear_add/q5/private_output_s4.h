#pragma once
#include "core/layout.h"
#include "fixed_output_mask.h"
#include "private_output_verify_policy.h"
#include <cuda_runtime.h>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
namespace ninfer::ops::detail {
// Private single-model registry. The model owns all cache bytes until all frames die.
inline constexpr std::size_t output_s4_code_bytes = 15728640;
inline constexpr std::size_t output_s4_scale_bytes = 245760;
inline constexpr std::size_t output_s4_layer_bytes = output_s4_code_bytes + output_s4_scale_bytes;
inline constexpr std::size_t output_s4_total_bytes = 47 * output_s4_layer_bytes;
struct OutputS4Scratch { std::uint8_t* codes; std::size_t code_bytes; float* scales; std::size_t scale_bytes; };
bool output_s4_enabled();
void output_s4_begin();
void output_s4_load_register(const Weight&, std::uint8_t*, int layer, cudaStream_t);
void output_s4_seal();
bool output_s4_registered(const Weight&);
void output_s4_launch(const Tensor&, const Weight&, Tensor&, const OutputS4Scratch&, cudaStream_t,
                      bool verify_phase = false);
template<class Allocator> OutputS4Scratch output_s4_workspace(Allocator& arena, int T) {
    if (T < 1 || T > 2048) throw std::invalid_argument("outputS4 workspace token domain");
    auto q = arena.alloc_bytes(std::size_t(T) * 3072);
    auto s = arena.alloc(DType::FP32, {T, 12});
    return {static_cast<std::uint8_t*>(q.data), std::size_t(T) * 3072,
            static_cast<float*>(s.data), std::size_t(T) * 48};
}
inline std::size_t output_s4_workspace_bytes(int T) {
    WorkspaceLayoutBuilder layout;
    (void)output_s4_workspace(layout, T);
    return layout.peak_bytes();
}
} // namespace ninfer::ops::detail
