#pragma once
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <cstdint>
namespace ucloud3::output_h512_quant {
// Fixed K17408,12 groups of512. Each warp handles its contiguous64
// channels in every group. First six butterflies are register/shuffle-local;
// final three exchange through shared memory with explicit read/write barriers.
__global__ void __launch_bounds__(256) kernel(const __nv_bfloat16* __restrict__ x,uint8_t* __restrict__ q,float* __restrict__ scale,float* rotated,int T){
 int t=blockIdx.x,tid=threadIdx.x,lane=tid&31,warp=tid>>5;
 float v[12][2];extern __shared__ float shared[];float* z=shared;auto* partial=reinterpret_cast<float (*)[8]>(shared+6144);
#pragma unroll
 for(int j=0;j<12;j++){
  int k=j*512+2*tid;auto p=*reinterpret_cast<const __nv_bfloat162*>(x+int64_t(t)*6144+k);
  v[j][0]=__fadd_rn(__bfloat162float(p.x),__bfloat162float(p.y));
  v[j][1]=__fsub_rn(__bfloat162float(p.x),__bfloat162float(p.y));
#pragma unroll
  for(int off=1;off<=16;off*=2){
#pragma unroll
   for(int e=0;e<2;e++){float other=__shfl_xor_sync(0xffffffffu,v[j][e],off);v[j][e]=(lane&off)?__fsub_rn(other,v[j][e]):__fadd_rn(v[j][e],other);}
  }
  z[k]=v[j][0];z[k+1]=v[j][1];
 }
 __syncthreads();
#pragma unroll
 for(int stride=64;stride<=256;stride*=2){
#pragma unroll
  for(int j=0;j<12;j++){
#pragma unroll
   for(int e=0;e<2;e++){int k=2*tid+e;float other=z[j*512+(k^stride)];v[j][e]=(k&stride)?__fsub_rn(other,v[j][e]):__fadd_rn(v[j][e],other);}
  }
  __syncthreads(); // every partner load precedes overwrite
#pragma unroll
  for(int j=0;j<12;j++){z[j*512+2*tid]=v[j][0];z[j*512+2*tid+1]=v[j][1];}
  __syncthreads(); // all next butterfly inputs published
 }
 // float32 RN(1/sqrt(512)), frozen CPU profile: bits0x3d3504f3.
 const float norm=__uint_as_float(0x3d3504f3u);
#pragma unroll
 for(int j=0;j<12;j++){
  float m=0;
#pragma unroll
  for(int e=0;e<2;e++){v[j][e]=__fmul_rn(v[j][e],norm);m=fmaxf(m,fabsf(v[j][e]));if(rotated)rotated[int64_t(t)*6144+j*512+2*tid+e]=v[j][e];}
#pragma unroll
  for(int off=16;off;off>>=1)m=fmaxf(m,__shfl_xor_sync(0xffffffffu,m,off));
  if(lane==0)partial[j][warp]=m;
 }
 __syncthreads();
#pragma unroll
 for(int j=0;j<12;j++){
  float m=0;
#pragma unroll
  for(int w=0;w<8;w++)m=fmaxf(m,partial[j][w]);
  float inv=m>0?__fdiv_rn(7.f,m):0.f;if(tid==0)scale[t*12+j]=m>0?__fdiv_rn(m,7.f):0.f;
  int a=max(-7,min(7,__float2int_rn(__fmul_rn(v[j][0],inv)))),b=max(-7,min(7,__float2int_rn(__fmul_rn(v[j][1],inv))));
  q[int64_t(t)*3072+j*256+tid]=uint8_t((a&15)|((b&15)<<4));
 }
}
}
