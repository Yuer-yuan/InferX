#pragma once
#include "ops/linear_attention/gated_delta_net/recurrent.cuh"
#include "ninfer/ops/gdn_replay_control.h"

namespace ninfer::ops::detail::gated_delta_net {
template <class Geometry_>
struct DeferredFoldAccess {
    using Geometry = Geometry_;
    const __nv_bfloat16 *key, *value;
    const uint2* gate;
    float* states;
    int width, old_row, slot;

    __device__ const __nv_bfloat16* key_base_ptr(const RecurrentCoordinates& c) const {
        return key + ((int64_t)old_row * width * Geometry::kQkHeads + c.qk_head) * 128;
    }

    __device__ const __nv_bfloat16* value_base_ptr(const RecurrentCoordinates& c) const {
        return value + ((int64_t)old_row * width * Geometry::kValueHeads + c.value_head) * 128;
    }

    __device__ const uint2* gate_base_ptr(const RecurrentCoordinates& c) const {
        return gate + (int64_t)old_row * width * Geometry::kValueHeads + c.value_head;
    }

    __device__ void store_final_state(const RecurrentCoordinates& c,
                                      const float (&state)[kDvPerWarp][kQkPerLane]) const {
        float* dst = states + ((int64_t)slot * Geometry::kValueHeads + c.value_head) * 128 * 128 +
                     (int64_t)c.dv_base * 128;
#pragma unroll
        for (int r = 0; r < kDvPerWarp; r++) store_qk_lane(state[r], dst + r * 128, c.dqk_base);
    }
};

template <class Geometry>
__global__ void __launch_bounds__(128, 2)
    deferred_record_kernel(RecordAccess<true> next, __nv_bfloat16* alternate_key,
                           __nv_bfloat16* alternate_value, uint2* alternate_gate,
                           const GdnReplayDeferredRow* controls) {
    auto c          = next.coordinates();
    const auto ctrl = controls[c.batch];
    DeferredFoldAccess<Geometry> old{ctrl.old_bank ? alternate_key : next.key_record,
                                     ctrl.old_bank ? alternate_value : next.value_record,
                                     ctrl.old_bank ? alternate_gate : next.gate_record,
                                     const_cast<float*>(next.states),
                                     next.width,
                                     ctrl.old_record_row,
                                     ctrl.linear_state_slot};
    if (ctrl.write_bank) {
        next.key_record   = alternate_key;
        next.value_record = alternate_value;
        next.gate_record  = alternate_gate;
    }
    __align__(16) float state[kDvPerWarp][kQkPerLane];
    const auto initial = next.state_read_base(c);
#pragma unroll
    for (int r = 0; r < kDvPerWarp; r++)
        load_qk_lane(state[r], initial + (int64_t)(c.dv_base + r) * 128, c.dqk_base);
    if (ctrl.old_record_row >= 0 && ctrl.accepted_columns > 0) {
        fold_in_registers(old, c, ctrl.accepted_columns, state);
        old.store_final_state(c, state);
    }
    record_in_registers<RecurrentMode::Record, true>(next, c, next.width, next.active_columns(c),
                                                     state);
}

template <class Geometry, bool Recurrent>
__global__ void __launch_bounds__(128, 2)
    partial_fold_kernel(const __grid_constant__ FoldAccess<Geometry> access) {
    auto c      = access.coordinates();
    const int n = access.active_columns(c);
    if (n <= 0) return;
    if constexpr (Recurrent) {
        __align__(16) float state[kDvPerWarp][kQkPerLane];
        const auto initial = access.state_read_base(c);
#pragma unroll
        for (int r = 0; r < kDvPerWarp; r++)
            load_qk_lane(state[r], initial + (int64_t)(c.dv_base + r) * 128, c.dqk_base);
        fold_in_registers(access, c, n, state);
        access.store_final_state(c, state);
    } else
        access.publish_final_conv_history(c, n);
}
} // namespace ninfer::ops::detail::gated_delta_net
