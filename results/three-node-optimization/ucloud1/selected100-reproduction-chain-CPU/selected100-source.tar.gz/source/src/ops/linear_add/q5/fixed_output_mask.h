#pragma once
#include <array>
namespace ninfer::ops::detail {
// Root fixed047 selection, no runtime/per-request mask search. Gate remains defaultOFF.
inline constexpr std::array<int,47> kOutputS4SelectedLayers = {1,2,4,5,6,8,9,10,12,13,14,16,17,18,20,21,22,24,25,26,28,29,30,32,33,34,36,37,38,40,41,42,44,45,46,48,49,50,52,53,54,56,57,58,60,61,62};
constexpr bool output_s4_selected_layer(int layer) noexcept {
    return layer > 0 && layer < 64 && (layer + 1) % 4 != 0;
}
static_assert(!output_s4_selected_layer(0) && !output_s4_selected_layer(3));
static_assert(output_s4_selected_layer(1) && output_s4_selected_layer(62));
} // namespace ninfer::ops::detail
