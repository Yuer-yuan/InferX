#pragma once
#include "private_output_s4.cuh"
#include "private_output_h512.cuh"
#include <cstdint>
#include <cstddef>
#include <stdexcept>

namespace ucloud3::output_s4_op {
constexpr int K=6144,N=5120,Groups=12;
constexpr std::size_t QuantSharedBytes=(K+Groups*8)*sizeof(float);
static_assert(QuantSharedBytes==24960);
struct Scratch { std::uint8_t* codes; std::size_t code_bytes; float* scales; std::size_t scale_bytes; };
inline bool overlap(const void* a,std::size_t an,const void* b,std::size_t bn){
 auto x=reinterpret_cast<std::uintptr_t>(a),y=reinterpret_cast<std::uintptr_t>(b);
 return x<=y ? y-x<an : x-y<bn;
}
inline cudaError_t prepare_attributes(){
 auto e=output_s4h512::prepare_attributes();if(e!=cudaSuccess)return e;
 return cudaFuncSetAttribute(output_h512_quant::kernel,cudaFuncAttributeMaxDynamicSharedMemorySize,int(QuantSharedBytes));
}
// Caller restricts this private candidate to generic Prefill,1<=T<=2048.
// Y is both the incoming BF16 residual and the final BF16 output. It must be
// disjoint from X and the quantization scratch. No residual copy is hidden here.
inline void launch(const __nv_bfloat16* X,const std::uint8_t* W,const float* Ws,
                   __nv_bfloat16* Y,Scratch q,int T,int sms,cudaStream_t stream){
 if(T<1||T>2048||sms<=0||!X||!W||!Ws||!Y||!q.codes||!q.scales)
  throw std::runtime_error("outputS4 fixed Prefill shape/pointer contract");
 const std::size_t xb=std::size_t(T)*K*2,yb=std::size_t(T)*N*2,qb=std::size_t(T)*K/2,sb=std::size_t(T)*Groups*4;
 if(q.code_bytes<qb||q.scale_bytes<sb||overlap(q.codes,qb,q.scales,sb)||
    overlap(X,xb,Y,yb)||overlap(X,xb,q.codes,qb)||overlap(X,xb,q.scales,sb)||
    overlap(Y,yb,q.codes,qb)||overlap(Y,yb,q.scales,sb))
  throw std::runtime_error("outputS4 disjoint scratch and residual contract");
 if((reinterpret_cast<std::uintptr_t>(X)|reinterpret_cast<std::uintptr_t>(W)|
     reinterpret_cast<std::uintptr_t>(Y)|reinterpret_cast<std::uintptr_t>(q.codes))&15u)
  throw std::runtime_error("outputS4 vector alignment");
 if((reinterpret_cast<std::uintptr_t>(Ws)|reinterpret_cast<std::uintptr_t>(q.scales))&3u)
  throw std::runtime_error("outputS4 scale alignment");
 output_h512_quant::kernel<<<T,256,QuantSharedBytes,stream>>>(X,q.codes,q.scales,nullptr,T);
 auto e=cudaGetLastError();if(e!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(e));
 output_s4h512::launch<false>(W,Ws,q.codes,q.scales,Y,nullptr,nullptr,0,T,sms,stream);
 e=cudaGetLastError();if(e!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(e));
}
} // namespace ucloud3::output_s4_op
