#pragma once
#include <cstdint>

namespace ninfer::ops {
// Device layout: five contiguous I32 values per active batch row. Logical ownership and record
// generations live in the runtime, never in this kernel-facing descriptor.
struct GdnReplayDeferredRow {
    std::int32_t old_record_row = -1, accepted_columns = 0, linear_state_slot = -1, old_bank = 0,
                 write_bank = 0;
};

static_assert(sizeof(GdnReplayDeferredRow) == 5 * sizeof(std::int32_t));
} // namespace ninfer::ops
