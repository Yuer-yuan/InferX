// Actual registered 27B dimensions; synthetic seeded codes and activations.
// Independent sampled FP64 oracle plus same-process cold CUDA-event A/B.
#include "ops/common/prefill_a8.h"
#include "ninfer/ops/linear_add.h"
#include "ninfer/ops/linear_swiglu.h"
#include "ninfer/ops/attn_input_proj.h"
#include "ninfer/ops/gdn_input_proj.h"
#include "ninfer_bench_common.h"
#include "quantized_weight.cuh"
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <memory>
#include <string>
#include <vector>
using namespace ninfer;
namespace d = ninfer::ops::detail;

__host__ __device__ unsigned mix(unsigned x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; return x ^ (x >> 16);
}
__host__ __device__ float activation(int k, int col) {
    float x = (static_cast<int>(mix(k + col * 8191U + 42) % 2001) - 1000) * 0.001f;
    if ((k + 7 * col) % 997 == 0) x *= 8.0f;
    return __bfloat162float(__float2bfloat16_rn(x));
}
__global__ void fill_x(__nv_bfloat16* out, int k, int cols) {
    for (long i = blockIdx.x * blockDim.x + threadIdx.x; i < static_cast<long>(k) * cols; i += gridDim.x * blockDim.x)
        out[i] = __float2bfloat16_rn(activation(i % k, i / k));
}
__global__ void fill_bytes(unsigned char* p, long count, unsigned seed) {
    for (long i = blockIdx.x * blockDim.x + threadIdx.x; i < count; i += gridDim.x * blockDim.x)
        p[i] = mix(static_cast<unsigned>(i) + seed) & 255;
}
__host__ __device__ float group_scale(long group) {
    return __half2float(__float2half_rn(0.004f + (mix(group + 515) % 1001) * 0.000008f));
}
__global__ void fill_scales(__half* p, long count) {
    for (long i = blockIdx.x * blockDim.x + threadIdx.x; i < count; i += gridDim.x * blockDim.x)
        p[i] = __float2half_rn(group_scale(i));
}
bench::PackedQuantizedWeight weight(QType type, int rows, int k) {
    auto w = bench::make_row_split_weight(type, rows, k, k);
    fill_bytes<<<1024,256>>>((unsigned char*)w.weight.qdata, w.low_bytes, 17);
    if (w.high_bytes) fill_bytes<<<1024,256>>>((unsigned char*)w.weight.qhigh, w.high_bytes, 29);
    fill_scales<<<1024,256>>>((__half*)w.weight.scales, static_cast<long>(rows) * k / 64);
    CUDA_CHECK(cudaDeviceSynchronize());
    return w;
}
// Exact independent unpack of represented Q4/Q5 two's-complement values.
double value(const Weight& w, int row, int k) {
    const long g = static_cast<long>(row) * (w.k / 64) + k / 64;
    const int lane = k % 64;
    unsigned byte = mix(static_cast<unsigned>(g * 32 + lane / 2) + 17) & 255;
    int code = (byte >> (4 * (lane % 2))) & 15;
    if (w.qtype == QType::Q5G64_F16S) {
        unsigned hi = mix(static_cast<unsigned>(g * 8 + lane / 8) + 29) & 255;
        code |= ((hi >> (lane % 8)) & 1) << 4;
        if (code >= 16) code -= 32;
    } else if (code >= 8) code -= 16;
    return code * static_cast<double>(group_scale(g));
}
double dot(const Weight& w, int row, int col) {
    double sum = 0;
    for (int j = 0; j < w.k; ++j) sum += value(w,row,j) * static_cast<double>(activation(j,col));
    return sum;
}

void run(const std::string& kind, int t) {
    const bool sw = kind == "swiglu", add = kind == "down" || kind == "out";
    const int k = kind == "down" ? 17408 : kind == "out" ? 6144 : 5120;
    const int n = sw ? 17408 : add ? 5120 : kind == "attn" ? 6144 : 10240;
    auto w0 = weight(sw || !add ? QType::Q4G64_F16S : QType::Q5G64_F16S,
                     sw ? 34816 : add ? 5120 : kind == "attn" ? 7168 : 4096, k);
    std::unique_ptr<bench::PackedQuantizedWeight> w1;
    if (!sw && !add) w1 = std::make_unique<bench::PackedQuantizedWeight>(weight(QType::Q5G64_F16S, kind == "attn" ? 7168 : 12288,k));
    std::vector<int> rows = sw || add ? std::vector<int>{n} : kind == "attn" ? std::vector<int>{6144,6144,1024,1024} : std::vector<int>{10240,6144};
    DeviceBuffer input(static_cast<size_t>(k)*t*2), flush(256ULL<<20);
    fill_x<<<1024,256>>>((__nv_bfloat16*)input.p,k,t);
    std::vector<DeviceBuffer> a,b;
    std::vector<Tensor> ao,bo;
    for (int r:rows) {
        a.emplace_back(static_cast<size_t>(r)*t*2); b.emplace_back(static_cast<size_t>(r)*t*2);
        ao.emplace_back(a.back().p,DType::BF16,std::initializer_list<int>{r,t});
        bo.emplace_back(b.back().p,DType::BF16,std::initializer_list<int>{r,t});
    }
    size_t bytes = d::prefill_a8_workspace_bytes(k,t);
    if(sw) bytes=std::max(bytes,ops::linear_swiglu_workspace_capacity_bytes(QType::Q4G64_F16S,34816,k,t,t));
    WorkspaceArena ws(std::max<size_t>(bytes,256));
    cudaStream_t stream; CUDA_CHECK(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));
    CUDA_CHECK(cudaDeviceSynchronize()); // Drain all Stream 0 setup before nonblocking stream.
    Tensor x(input.p,DType::BF16,{k,t});
    auto launch = [&](bool a8) {
        auto scope=ws.scope();
        if(a8) {
            const auto scratch=d::prefill_a8_workspace(ws,k,t);
            if(sw) d::q4_linear_swiglu_int8_folded_launch(x,w0.weight,bo[0],scratch,stream);
            else if(add) d::q5_linear_add_int8_residual_launch(x,w0.weight,bo[0],scratch,stream);
            else if(kind=="attn") d::q4_q5_attn_input_int8_launch(x,w0.weight,w1->weight,bo[0],bo[1],bo[2],bo[3],scratch,stream);
            else d::q4_q5_gdn_input_int8_launch(x,w0.weight,w1->weight,bo[0],bo[1],scratch,stream);
        } else {
            if(sw) ops::linear_swiglu(x,w0.weight,ao[0],ws,stream);
            else if(add) ops::linear_add(x,w0.weight,ao[0],ws,stream);
            else if(kind=="attn") ops::attn_input_proj(x,w0.weight,w1->weight,ao[0],ao[1],ao[2],ao[3],stream);
            else ops::gdn_input_proj(x,w0.weight,w1->weight,ao[0],ao[1],stream);
        }
    };
    auto reset=[&](bool a8) {if(add) CUDA_CHECK(cudaMemsetAsync(a8?b[0].p:a[0].p,0,a[0].bytes,stream));};
    auto timing=[&](bool a8) {
        std::vector<double> samples;
        cudaEvent_t begin,end; CUDA_CHECK(cudaEventCreate(&begin)); CUDA_CHECK(cudaEventCreate(&end));
        for(int i=0;i<13;++i) {
            bench::flush_l2(flush,stream); reset(a8);
            CUDA_CHECK(cudaEventRecord(begin,stream)); launch(a8); CUDA_CHECK(cudaEventRecord(end,stream));
            CUDA_CHECK(cudaEventSynchronize(end)); float ms; CUDA_CHECK(cudaEventElapsedTime(&ms,begin,end));
            if(i>=3) samples.push_back(ms*1000.0);
        }
        CUDA_CHECK(cudaEventDestroy(begin)); CUDA_CHECK(cudaEventDestroy(end));
        return bench::summarize_timings(samples).median_us;
    };
    // Alternate the ordering across T to reduce order/thermal bias; record order.
    double ta,tb;
    bool a8_first=(t%3)==1;
    if(a8_first) {tb=timing(true);ta=timing(false);} else {ta=timing(false);tb=timing(true);}
    reset(false);reset(true);launch(false);launch(true);CUDA_CHECK(cudaStreamSynchronize(stream));
    double err_a=0,err_b=0,signal=0,pairerr=0,pairsignal=0,max_b=0;
    int count=0,nonfinite=0;
    for(size_t oi=0;oi<rows.size();++oi) {
        std::vector<__nv_bfloat16> ha(static_cast<size_t>(rows[oi])*t),hb(ha.size());
        a[oi].copy_to_host(ha.data(),a[oi].bytes);b[oi].copy_to_host(hb.data(),b[oi].bytes);
        for(size_t j=0;j<ha.size();++j) {
            double va=__bfloat162float(ha[j]),vb=__bfloat162float(hb[j]);
            nonfinite+=!std::isfinite(va)||!std::isfinite(vb);pairerr+=(va-vb)*(va-vb);pairsignal+=va*va;
        }
        for(int col:std::vector<int>{0,1,t/2,t-1}) for(int r:std::vector<int>{0,1,63,64,rows[oi]/2,rows[oi]-1}) {
            double ref;
            if(sw) {double gate=dot(w0.weight,r,col),up=dot(w0.weight,r+17408,col);ref=(gate/(1+std::exp(-gate)))*up;}
            else if(add) ref=dot(w0.weight,r,col);
            else if(kind=="attn") ref=dot(oi==0||oi==2?w0.weight:w1->weight,r+(oi>=2?6144:0),col);
            else ref=oi==1?dot(w1->weight,r+6144,col):r<4096?dot(w0.weight,r,col):dot(w1->weight,r-4096,col);
            double va=__bfloat162float(ha[static_cast<size_t>(col)*rows[oi]+r]);
            double vb=__bfloat162float(hb[static_cast<size_t>(col)*rows[oi]+r]);
            err_a+=(va-ref)*(va-ref);err_b+=(vb-ref)*(vb-ref);signal+=ref*ref;max_b=std::max(max_b,std::abs(vb-ref));count++;
            std::printf("{\"type\":\"oracle_sample\",\"op\":\"%s\",\"T\":%d,\"output\":%zu,\"row\":%d,\"col\":%d,\"fp64\":%.12g,\"bf16_route\":%.12g,\"a8_route\":%.12g}\n",kind.c_str(),t,oi,r,col,ref,va,vb);
        }
    }
    double nrma=std::sqrt(err_a/std::max(signal,1e-30)),nrmb=std::sqrt(err_b/std::max(signal,1e-30));
    bool pass=nonfinite==0 && nrmb<(sw?0.05:0.03) && nrma<0.02;
    std::printf("{\"type\":\"result\",\"op\":\"%s\",\"T\":%d,\"K\":%d,\"source\":\"seeded_synthetic_actual_shape\",\"seed\":42,\"timing\":\"cold_256MiB_flush_cuda_event_quantization_included_10_samples\",\"a8_first\":%s,\"baseline_us\":%.4f,\"a8_us\":%.4f,\"speedup\":%.5f,\"workspace_bytes\":%zu,\"oracle_samples\":%d,\"baseline_fp64_nrmse\":%.8g,\"a8_fp64_nrmse\":%.8g,\"a8_fp64_max_abs\":%.8g,\"a8_vs_baseline_nrmse\":%.8g,\"nonfinite\":%d,\"smoke_pass\":%s}\n",kind.c_str(),t,k,a8_first?"true":"false",ta,tb,ta/tb,bytes,count,nrma,nrmb,max_b,std::sqrt(pairerr/std::max(pairsignal,1e-30)),nonfinite,pass?"true":"false");
    CUDA_CHECK(cudaStreamDestroy(stream));
    if(!pass) throw std::runtime_error("A8 sampled mathematical oracle smoke failed");
}
int main(int argc,char**argv) {
    try {
        for(int i=1;i<argc;++i) for(const char* op:{"swiglu","down","out","attn","gdn"}) run(op,std::stoi(argv[i]));
    } catch(const std::exception& e) {std::fprintf(stderr,"probe failure: %s\n",e.what());return 1;}
}
