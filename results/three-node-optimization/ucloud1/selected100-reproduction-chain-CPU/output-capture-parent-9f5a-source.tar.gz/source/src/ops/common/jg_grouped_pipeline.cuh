#pragma once
// Reuse immutable pipeline-v1 selected headers/helper; no ABI or runtime import.
#include "ops/common/jg_pipeline_adapter.cuh"
#include <span>
namespace ninfer::ops::detail {
inline void jg_grouped_launch(const Tensor& x,const Weight& w0,const Weight& w1,
 std::span<Tensor> out,const Int8ProjWorkspace& scratch,cudaStream_t stream,bool attn) {
 const int k=x.ne[0];
 if(out.size()!=(attn?4:2))throw std::invalid_argument("grouped output arity mismatch");
 if(k!=5120 || w0.padded_shape[1]!=k || w1.padded_shape[1]!=k)
  throw std::invalid_argument("grouped pipeline probe expects registered unpadded K5120");
 for(int offset=0;offset<x.ne[1];offset+=4096) {
  const int t=std::min(4096,x.ne[1]-offset);Tensor xs=x.slice(1,offset,t);
  act_quant_g64_launch(static_cast<const __nv_bfloat16*>(xs.data),scratch.codes,scratch.scales,k,t,k,stream);
  rowsplit_tall::GroupedProblem p{};int blocks;
  if(attn) {
   Tensor q=out[0].slice(1,offset,t),g=out[1].slice(1,offset,t),key=out[2].slice(1,offset,t),v=out[3].slice(1,offset,t);
   p={{{rowsplit_tall::grouped_job(w0,0,6144,static_cast<__nv_bfloat16*>(q.data),q.ne[0],0)},
       {rowsplit_tall::grouped_job(w0,6144,1024,static_cast<__nv_bfloat16*>(key.data),key.ne[0],0)},
       {rowsplit_tall::grouped_job(w1,0,6144,static_cast<__nv_bfloat16*>(g.data),g.ne[0],0)},
       {rowsplit_tall::grouped_job(w1,6144,1024,static_cast<__nv_bfloat16*>(v.data),v.ne[0],0)}}};
   blocks=112;
  } else {
   Tensor qkv=out[0].slice(1,offset,t),z=out[1].slice(1,offset,t);auto* qkv_out=static_cast<__nv_bfloat16*>(qkv.data);
   p={{{rowsplit_tall::grouped_job(w0,0,4096,qkv_out,qkv.ne[0],0)},
       {rowsplit_tall::grouped_job(w1,0,6144,qkv_out,qkv.ne[0],4096)},
       {rowsplit_tall::grouped_job(w1,6144,6144,static_cast<__nv_bfloat16*>(z.data),z.ne[0],0)}, {}}};
   blocks=128;
  }
  rowsplit_tall_a8::launch<128,false>(p,blocks,scratch.codes,scratch.scales,k,t,stream);
 }
}
}
