#include "ops/common/prefill_a8.h"
#include "ops/common/jg_grouped_pipeline.cuh"
#include <array>
namespace ninfer::ops::detail {
void q4_q5_gdn_input_int8_launch(const Tensor& x,const Weight& w0,const Weight& w1,Tensor& qkv,Tensor& z,const Int8ProjWorkspace& scratch,cudaStream_t stream) {std::array<Tensor,2> out{qkv,z};jg_grouped_launch(x,w0,w1,std::span<Tensor>(out),scratch,stream,false);}
}
