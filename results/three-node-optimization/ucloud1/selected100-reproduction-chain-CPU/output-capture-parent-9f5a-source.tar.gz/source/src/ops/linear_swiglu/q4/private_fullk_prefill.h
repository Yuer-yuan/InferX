#pragma once
#include "core/tensor.h"
#include "ops/common/int8_proj_launch.h"
#include <cuda_runtime.h>
#include <cstdint>
#include <cstddef>
namespace ninfer::ops::detail {
struct FullKGateView {const int8_t* codes=nullptr;const float* scales=nullptr;int layer=-1;};
inline constexpr std::size_t fullk_codes_bytes=std::size_t(34816)*5120;
inline constexpr std::size_t fullk_scales_bytes=std::size_t(34816)*4;
bool fullk_prefill_enabled();
bool fullk_s4_enabled();
// Fixed per process before frame planning and Graph capture; only target FFN.
bool fullk_s4_target_enabled();
bool fullk_s4_omit_legacy_enabled();
bool fullk_s4_selected_layer(int);
inline constexpr std::size_t s4_gate_codes=std::size_t(34816)*5120/2,s4_gate_scales=std::size_t(34816)*10*4;
inline constexpr std::size_t s4_down_codes=std::size_t(5120)*17408/2,s4_down_scales=std::size_t(5120)*34*4;
inline constexpr std::size_t s4_layer_bytes=s4_gate_codes+s4_gate_scales+s4_down_codes+s4_down_scales;
void fullk_load_s4_cache(int8_t*,float*,int,cudaStream_t);
void fullk_prepare();
void fullk_build_cache(const Weight&,int8_t*,float*,int*,cudaStream_t);
void fullk_gate_launch(const Tensor&,const FullKGateView&,Tensor&,const Int8ProjWorkspace&,cudaStream_t);
void fullk_down_launch(const Tensor&,const FullKGateView&,Tensor&,const Int8ProjWorkspace&,cudaStream_t);
void fullk_capture_down(const Tensor&,const Tensor&,int,bool,cudaStream_t);
void fullk_capture_actual(const Tensor&,const Tensor&,const Weight&,int,cudaStream_t);
}
