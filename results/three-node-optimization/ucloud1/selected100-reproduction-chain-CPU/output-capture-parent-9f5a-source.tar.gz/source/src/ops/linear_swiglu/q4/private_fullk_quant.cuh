#pragma once
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cstdint>
namespace ninfer::ops::detail::fullk_private {
__global__ void fullk_token_quant(const __nv_bfloat16* x,int8_t* q,float* s,int T){
    const int t=blockIdx.x;if(t>=T)return;__shared__ float maxima[256];float values[20],m=0;
#pragma unroll
    for(int j=0;j<20;++j){float v=__bfloat162float(x[int64_t(t)*5120+threadIdx.x+j*256]);values[j]=v;m=fmaxf(m,fabsf(v));}
    maxima[threadIdx.x]=m;__syncthreads();
    for(int d=128;d;d>>=1){if(threadIdx.x<d)maxima[threadIdx.x]=fmaxf(maxima[threadIdx.x],maxima[threadIdx.x+d]);__syncthreads();}
    float a=maxima[0],scale=a>0?__fdiv_rn(a,127.f):0.f,inv=a>0?__fdiv_rn(127.f,a):0.f;
    if(threadIdx.x==0)s[t]=scale;
#pragma unroll
    for(int j=0;j<20;++j){int code=__float2int_rn(__fmul_rn(values[j],inv));q[int64_t(t)*5120+threadIdx.x+j*256]=int8_t(max(-127,min(127,code)));}
}

// Same frozen logical weight: FP32(signedQ4*F16scale), no intermediate BF16/F16 cast.
__global__ void build_cache(const uint8_t* packed,const __half* groups,int8_t* q,float* scales,int* invalid){
 const int row=blockIdx.x,tid=threadIdx.x;__shared__ float maxima[256];float values[20],m=0;
#pragma unroll
 for(int j=0;j<20;++j){const int k=tid+j*256;const uint8_t p=packed[int64_t(row)*2560+k/2];const int code=int((p>>(4*(k&1)))&15)^8;const float v=__fmul_rn(float(code-8),__half2float(groups[int64_t(row)*80+k/64]));values[j]=v;if(!isfinite(v))atomicExch(invalid,1);m=fmaxf(m,fabsf(v));}
 maxima[tid]=m;__syncthreads();
 for(int d=128;d;d>>=1){if(tid<d)maxima[tid]=fmaxf(maxima[tid],maxima[tid+d]);__syncthreads();}
 const float a=maxima[0],scale=a>0?__fdiv_rn(a,127.f):0.f,inv=a>0?__fdiv_rn(127.f,a):0.f;if(tid==0)scales[row]=scale;
#pragma unroll
 for(int j=0;j<20;++j){const int code=__float2int_rn(__fmul_rn(values[j],inv));q[int64_t(row)*5120+tid+j*256]=int8_t(max(-127,min(127,code)));}
}
}
