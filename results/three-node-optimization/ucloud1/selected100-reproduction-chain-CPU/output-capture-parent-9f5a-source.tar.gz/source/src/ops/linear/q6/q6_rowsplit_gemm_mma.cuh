#pragma once

// Q6G64 RowSplit x BF16 Tensor Core GEMM.
//
// out[Rows, Cols] = W[Rows, K] * x[K, Cols]
//
// Each CTA owns a BlockRows x BlockCols output tile and advances K in one or more
// complete 64-value quant groups. Raw Q6 code/high planes and FP16 scales are
// staged independently from the BF16 activation tile. Q6 values are decoded
// to BF16 in shared memory, then consumed by m16n8k16 BF16 MMA with FP32
// accumulation.
//
// The template describes only physical kernel structure. Rows, Cols, and K
// remain runtime dimensions; registered shapes select a closed schedule and a
// statically compiled boundary variant outside the kernel.

#include "ops/common/mma.cuh"
#include "ops/linear/q6/q6_rowsplit_storage.cuh"

#include <cuda_bf16.h>
#include <cuda_fp16.h>

#include <cstdint>

namespace ninfer::ops::detail {

enum class Q6FragmentPipeline {
    Serial,
    PingPong,
};

enum class Q6ScaleLoad {
    Scalar16,
    Pair32,
};

template <int BlockRows_, int BlockCols_, int BlockK_, int WarpRows_, int WarpCols_,
          int PipelineStages_, int LaunchBoundsMinBlocks_, Q6FragmentPipeline FragmentPipeline_,
          Cache QuantCache_, Cache ActivationCache_, Q6ScaleLoad ScaleLoadMode_,
          int ActivationStages_ = PipelineStages_>
struct Q6RowSplitMmaGemmSchedule {
    static constexpr int kBlockRows = BlockRows_;
    static constexpr int kBlockCols = BlockCols_;
    static constexpr int kBlockK    = BlockK_;
    static constexpr int kWarpRows  = WarpRows_;
    static constexpr int kWarpCols  = WarpCols_;

    static constexpr int kPipelineStages                  = PipelineStages_;
    static constexpr int kLaunchBoundsMinBlocks           = LaunchBoundsMinBlocks_;
    static constexpr Q6FragmentPipeline kFragmentPipeline = FragmentPipeline_;
    static constexpr Cache kQuantCache                    = QuantCache_;
    static constexpr Cache kActivationCache               = ActivationCache_;
    static constexpr Q6ScaleLoad kScaleLoadMode           = ScaleLoadMode_;
    static constexpr int kActivationStages                = ActivationStages_;

    static constexpr int kWarpGridRows = kBlockRows / kWarpRows;
    static constexpr int kWarpGridCols = kBlockCols / kWarpCols;
    static constexpr int kWarps        = kWarpGridRows * kWarpGridCols;
    static constexpr int kThreads      = kWarps * 32;
    static constexpr int kMmaRows      = kWarpRows / 16;
    static constexpr int kMmaCols      = kWarpCols / 8;
    static constexpr int kMmaKSteps    = kBlockK / 16;
    static constexpr int kGroupsPerK   = kBlockK / Q6RowSplitStorage::kGroupK;
    static constexpr int kScaleBytes =
        kScaleLoadMode == Q6ScaleLoad::Pair32 ? 4 : Q6RowSplitStorage::kScaleBytesPerGroup;

    static constexpr int kSharedBytes =
        kBlockRows * kBlockK * static_cast<int>(sizeof(__nv_bfloat16)) +
        kActivationStages * kBlockCols * kBlockK * static_cast<int>(sizeof(__nv_bfloat16)) +
        kPipelineStages * kBlockRows * kGroupsPerK * Q6RowSplitStorage::kCodeBytesPerGroup +
        kPipelineStages * kBlockRows * kGroupsPerK * Q6RowSplitStorage::kHighBytesPerGroup +
        kPipelineStages * kBlockRows * kGroupsPerK * kScaleBytes;

    static_assert(kBlockRows > 0 && kBlockCols > 0);
    static_assert(kBlockK % Q6RowSplitStorage::kGroupK == 0,
                  "Q6 MMA K tile must contain complete quant groups");
    static_assert(kBlockRows % kWarpRows == 0 && kBlockCols % kWarpCols == 0,
                  "Q6 MMA block tile must divide into warp tiles");
    static_assert(kWarpRows % 16 == 0 && kWarpCols % 8 == 0,
                  "Q6 MMA warp tile must be composed of m16n8 MMA tiles");
    static_assert(kPipelineStages >= 1 && kPipelineStages <= 8,
                  "Q6 MMA cp.async pipeline depth must fit cp_wait");
    static_assert(kActivationStages == 1 || kActivationStages == kPipelineStages,
                  "Q6 MMA activation staging is single-buffered or follows the quant pipeline");
    static_assert(kLaunchBoundsMinBlocks >= 1);
    static_assert(kWarps >= 1 && kThreads <= 1024);
    static_assert(kSharedBytes <= 48 * 1024,
                  "Q6 MMA staged shared memory exceeds the static 48 KiB budget");
};

// XOR swizzle for a [rows][64] BF16 tile. The eight 16-byte column groups are
// permuted by the low row bits so ldmatrix reads do not repeatedly hit the same
// shared-memory bank group.
__device__ __forceinline__ int q6_mma_swizzle_k64(int row, int col) {
    return (((col >> 3) ^ (row & 7)) << 3) | (col & 7);
}

// clang-format off
template <class Schedule_, bool Full>
__global__ __launch_bounds__(Schedule_::kThreads, Schedule_::kLaunchBoundsMinBlocks)
void q6_rowsplit_gemm_mma_kernel(
    const __nv_bfloat16* __restrict__ x,
    const std::uint8_t* __restrict__ codes,
    const std::uint8_t* __restrict__ high,
    const std::uint8_t* __restrict__ scales,
    __nv_bfloat16* __restrict__ out,
    std::int32_t rows,
    std::int32_t k,
    std::int32_t cols,
    std::int32_t padded_k) {
    // clang-format on
    using Schedule       = Schedule_;
    constexpr bool kFull = Full;
    constexpr int BM     = Schedule::kBlockRows;
    constexpr int BN     = Schedule::kBlockCols;
    constexpr int BK     = Schedule::kBlockK;
    constexpr int WM     = Schedule::kWarpRows;
    constexpr int WN     = Schedule::kWarpCols;
    constexpr int MT     = Schedule::kMmaRows;
    constexpr int NT     = Schedule::kMmaCols;
    constexpr int KSUB   = Schedule::kMmaKSteps;
    constexpr int S      = Schedule::kPipelineStages;
    constexpr int BS     = Schedule::kActivationStages;
    constexpr int GPB    = Schedule::kGroupsPerK;
    constexpr int SB     = Schedule::kScaleBytes;

    __shared__ __align__(16) __nv_bfloat16 As[BM * BK];
    __shared__ __align__(16) __nv_bfloat16 Bs[BS][BN * BK];
    __shared__ __align__(16) std::uint8_t Cr[S][BM * GPB * Q6RowSplitStorage::kCodeBytesPerGroup];
    __shared__ __align__(16) std::uint8_t Hr[S][BM * GPB * Q6RowSplitStorage::kHighBytesPerGroup];
    __shared__ __align__(16) std::uint8_t Sr[S][BM * GPB * SB];

    const int groups_per_row = padded_k / Q6RowSplitStorage::kGroupK;
    const int tid            = static_cast<int>(threadIdx.x);
    const int warp           = tid >> 5;
    const int lane           = tid & 31;
    const int warp_row       = warp / Schedule::kWarpGridCols;
    const int warp_col       = warp % Schedule::kWarpGridCols;
    const int mma_row        = lane >> 2;
    const int mma_col        = lane & 3;

    const int row0 = static_cast<int>(blockIdx.x) * BM;
    const int col0 = static_cast<int>(blockIdx.y) * BN;

    float accum[MT][NT][4];
#pragma unroll
    for (int mi = 0; mi < MT; ++mi) {
#pragma unroll
        for (int ni = 0; ni < NT; ++ni) {
            accum[mi][ni][0] = 0.0f;
            accum[mi][ni][1] = 0.0f;
            accum[mi][ni][2] = 0.0f;
            accum[mi][ni][3] = 0.0f;
        }
    }

    const int k_tiles = padded_k / BK;

    const int a_matrix     = lane >> 3;
    const int a_inner_row  = lane & 7;
    const int a_row_offset = a_inner_row + ((a_matrix & 1) << 3);
    const int a_col_offset = (a_matrix >> 1) << 3;
    const int b_inner_row  = lane & 7;
    const int b_k_offset   = ((lane >> 3) & 1) << 3;

    auto stage_activation = [&](int stage, int k_tile) {
        const int k0 = k_tile * BK;
#pragma unroll 1
        for (int item = tid; item < BN * (BK / 8); item += Schedule::kThreads) {
            const int local_col = item / (BK / 8);
            const int k8        = item - local_col * (BK / 8);
            const int kk        = k0 + k8 * 8;
            const int col       = col0 + local_col;
            auto* dst = &Bs[stage][local_col * BK + q6_mma_swizzle_k64(local_col, k8 * 8)];
            if constexpr (kFull) {
                cp_async<16, Schedule::kActivationCache>(
                    dst, &x[static_cast<std::int64_t>(col) * k + kk]);
            } else {
                if (col < cols && kk + 8 <= k) {
                    cp_async<16, Schedule::kActivationCache>(
                        dst, &x[static_cast<std::int64_t>(col) * k + kk]);
                } else {
                    store_vec(dst, make_int4(0, 0, 0, 0));
                }
            }
        }
    };

    auto stage_quant = [&](int stage, int k_tile) {
        const int group0 = (k_tile * BK) / Q6RowSplitStorage::kGroupK;
#pragma unroll 1
        for (int item = tid; item < BM * GPB * 2; item += Schedule::kThreads) {
            const int row_group = item >> 1;
            const int half      = item & 1;
            const int local_row = row_group / GPB;
            const int group     = row_group - local_row * GPB;
            const int row       = row0 + local_row;
            auto* dst = &Cr[stage][row_group * Q6RowSplitStorage::kCodeBytesPerGroup + half * 16];
            if constexpr (kFull) {
                const std::int64_t group_index =
                    (static_cast<std::int64_t>(row) * groups_per_row + group0) + group;
                cp_async<16, Schedule::kQuantCache>(
                    dst, &codes[group_index * Q6RowSplitStorage::kCodeBytesPerGroup + half * 16]);
            } else {
                if (row < rows) {
                    const std::int64_t group_index =
                        (static_cast<std::int64_t>(row) * groups_per_row + group0) + group;
                    cp_async<16, Schedule::kQuantCache>(
                        dst,
                        &codes[group_index * Q6RowSplitStorage::kCodeBytesPerGroup + half * 16]);
                } else {
                    store_vec(dst, make_int4(0, 0, 0, 0));
                }
            }
        }

#pragma unroll 1
        for (int row_group = tid; row_group < BM * GPB; row_group += Schedule::kThreads) {
            const int local_row = row_group / GPB;
            const int group     = row_group - local_row * GPB;
            const int row       = row0 + local_row;
            auto* dst           = &Hr[stage][row_group * Q6RowSplitStorage::kHighBytesPerGroup];
            if constexpr (kFull) {
                const std::int64_t group_index =
                    (static_cast<std::int64_t>(row) * groups_per_row + group0) + group;
                cp_async<16, Schedule::kQuantCache>(
                    dst, &high[group_index * Q6RowSplitStorage::kHighBytesPerGroup]);
            } else {
                if (row < rows) {
                    const std::int64_t group_index =
                        (static_cast<std::int64_t>(row) * groups_per_row + group0) + group;
                    cp_async<16, Schedule::kQuantCache>(
                        dst, &high[group_index * Q6RowSplitStorage::kHighBytesPerGroup]);
                } else {
                    store_vec(dst, make_int4(0, 0, 0, 0));
                }
            }
        }

#pragma unroll 1
        for (int row_group = tid; row_group < BM * GPB; row_group += Schedule::kThreads) {
            const int local_row   = row_group / GPB;
            const int group       = row_group - local_row * GPB;
            const int row         = row0 + local_row;
            const int scale_group = group0 + group;
            auto* dst             = &Sr[stage][row_group * SB];
            if constexpr (kFull) {
                const std::int64_t row_group_base = static_cast<std::int64_t>(row) * groups_per_row;
                const std::int64_t group_index    = row_group_base + scale_group;
                if constexpr (Schedule::kScaleLoadMode == Q6ScaleLoad::Pair32) {
                    const int aligned_group          = scale_group & ~1;
                    const std::int64_t aligned_index = row_group_base + aligned_group;
                    if (aligned_group + 1 < groups_per_row) {
                        cp_async<4>(
                            dst, &scales[aligned_index * Q6RowSplitStorage::kScaleBytesPerGroup]);
                    } else {
                        *reinterpret_cast<std::uint16_t*>(dst) =
                            *reinterpret_cast<const std::uint16_t*>(
                                &scales[group_index * Q6RowSplitStorage::kScaleBytesPerGroup]);
                        *reinterpret_cast<std::uint16_t*>(dst + 2) = 0;
                    }
                } else {
                    *reinterpret_cast<std::uint16_t*>(dst) =
                        *reinterpret_cast<const std::uint16_t*>(
                            &scales[group_index * Q6RowSplitStorage::kScaleBytesPerGroup]);
                }
            } else {
                if (row < rows) {
                    const std::int64_t row_group_base = static_cast<std::int64_t>(row) * groups_per_row;
                    const std::int64_t group_index    = row_group_base + scale_group;
                    if constexpr (Schedule::kScaleLoadMode == Q6ScaleLoad::Pair32) {
                        const int aligned_group          = scale_group & ~1;
                        const std::int64_t aligned_index = row_group_base + aligned_group;
                        if (aligned_group + 1 < groups_per_row) {
                            cp_async<4>(
                                dst,
                                &scales[aligned_index * Q6RowSplitStorage::kScaleBytesPerGroup]);
                        } else {
                            *reinterpret_cast<std::uint16_t*>(dst) =
                                *reinterpret_cast<const std::uint16_t*>(
                                    &scales[group_index * Q6RowSplitStorage::kScaleBytesPerGroup]);
                            *reinterpret_cast<std::uint16_t*>(dst + 2) = 0;
                        }
                    } else {
                        *reinterpret_cast<std::uint16_t*>(dst) =
                            *reinterpret_cast<const std::uint16_t*>(
                                &scales[group_index * Q6RowSplitStorage::kScaleBytesPerGroup]);
                    }
                } else {
                    dst[0] = 0;
                    dst[1] = 0;
                    if constexpr (Schedule::kScaleLoadMode == Q6ScaleLoad::Pair32) {
                        dst[2] = 0;
                        dst[3] = 0;
                    }
                }
            }
        }
    };

    auto stage_inputs = [&](int stage, int k_tile) {
        stage_activation(stage, k_tile);
        stage_quant(stage, k_tile);
    };

    auto decode_weight = [&](int stage, int k_tile) {
        const int scale_group = (k_tile * BK) / Q6RowSplitStorage::kGroupK;
        // q6_mma_swizzle_k64 permutes whole eight-element runs, so eight codes are the widest chunk that
        // stays contiguous in As for every row, and the chunk lies inside one quantisation group.
        // The loop is indexed by thread over chunks, so a thread reads its own scale halfword,
        // decodes eight codes out of one 32-bit code word and stores them with one 16-byte store
        // instead of four 4-byte ones.
        constexpr int kChunks = Q6RowSplitStorage::kChunksPerGroup;
        static_assert(GPB * kChunks * 8 == BK,
                      "the block's groups must decode to exactly the tile's k width");
        for (int item = tid; item < BM * GPB * kChunks; item += Schedule::kThreads) {
            const int staged_group = item / kChunks;
            const int chunk        = item - staged_group * kChunks;
            const int local_row    = staged_group / GPB;
            const int group        = staged_group - local_row * GPB;
            const std::uint8_t* scale_ptr =
                &Sr[stage][staged_group * SB + (Schedule::kScaleLoadMode == Q6ScaleLoad::Pair32
                                                    ? ((scale_group + group) & 1) *
                                                          Q6RowSplitStorage::kScaleBytesPerGroup
                                                    : 0)];
            const float scale =
                __half2float(__ushort_as_half(*reinterpret_cast<const std::uint16_t*>(scale_ptr)));
            unsigned decoded[4];
            Q6MmaDecodeAtom::decode_eight(
                *reinterpret_cast<const unsigned*>(
                    &Cr[stage][staged_group * Q6RowSplitStorage::kCodeBytesPerGroup +
                               chunk * Q6RowSplitStorage::kCodeBytesPerChunk]),
                &Hr[stage][staged_group * Q6RowSplitStorage::kHighBytesPerGroup +
                           chunk * Q6RowSplitStorage::kHighBytesPerChunk],
                scale, decoded);
            store_vec(&As[local_row * BK +
                          q6_mma_swizzle_k64(local_row, group * Q6RowSplitStorage::kGroupK + chunk * 8)],
                      make_int4(static_cast<int>(decoded[0]), static_cast<int>(decoded[1]),
                                static_cast<int>(decoded[2]), static_cast<int>(decoded[3])));
        }
    };

    if constexpr (BS == S) {
#pragma unroll
        for (int stage = 0; stage < S; ++stage) {
            if (stage < k_tiles) { stage_inputs(stage, stage); }
            cp_commit();
        }
    } else {
#pragma unroll
        for (int stage = 0; stage < S; ++stage) {
            if (stage < k_tiles) { stage_quant(stage, stage); }
            cp_commit();
        }
        if (k_tiles > 0) { stage_activation(0, 0); }
        cp_commit();
    }

    for (int k_tile = 0; k_tile < k_tiles; ++k_tile) {
        const int stage = k_tile % S;
        if constexpr (BS == S) {
            cp_wait<S - 1>();
        } else {
            cp_wait<0>();
        }
        __syncthreads();

        decode_weight(stage, k_tile);
        __syncthreads();

        if constexpr (BS == 1) {
            const int prefetch_quant_tile = k_tile + S;
            if (prefetch_quant_tile < k_tiles) { stage_quant(stage, prefetch_quant_tile); }
            cp_commit();
        }

        auto load_fragments = [&](int k_step, unsigned(&a_frag)[MT][4], unsigned(&b_frag)[NT][2]) {
#pragma unroll
            for (int mi = 0; mi < MT; ++mi) {
                const int row = warp_row * WM + mi * 16 + a_row_offset;
                const int col = k_step + a_col_offset;
                ldmatrix_x4(a_frag[mi][0], a_frag[mi][1], a_frag[mi][2], a_frag[mi][3],
                            smem_addr(&As[row * BK + q6_mma_swizzle_k64(row, col)]));
            }
#pragma unroll
            for (int ni = 0; ni < NT; ++ni) {
                const int row = warp_col * WN + ni * 8 + b_inner_row;
                const int col = k_step + b_k_offset;
                ldmatrix_x2(
                    b_frag[ni][0], b_frag[ni][1],
                    smem_addr(&Bs[BS == 1 ? 0 : stage][row * BK + q6_mma_swizzle_k64(row, col)]));
            }
        };

        if constexpr (Schedule::kFragmentPipeline == Q6FragmentPipeline::PingPong) {
            unsigned a_frag[2][MT][4];
            unsigned b_frag[2][NT][2];
            load_fragments(0, a_frag[0], b_frag[0]);
#pragma unroll
            for (int ki = 0; ki < KSUB; ++ki) {
                const int current = ki & 1;
                const int next    = (ki + 1) & 1;
                if (ki + 1 < KSUB) { load_fragments((ki + 1) * 16, a_frag[next], b_frag[next]); }
#pragma unroll
                for (int mi = 0; mi < MT; ++mi) {
#pragma unroll
                    for (int ni = 0; ni < NT; ++ni) {
                        mma_bf16(accum[mi][ni][0], accum[mi][ni][1], accum[mi][ni][2],
                                 accum[mi][ni][3], a_frag[current][mi][0], a_frag[current][mi][1],
                                 a_frag[current][mi][2], a_frag[current][mi][3],
                                 b_frag[current][ni][0], b_frag[current][ni][1]);
                    }
                }
            }
        } else {
            unsigned a_frag[MT][4];
            unsigned b_frag[NT][2];
#pragma unroll
            for (int ki = 0; ki < KSUB; ++ki) {
                load_fragments(ki * 16, a_frag, b_frag);
#pragma unroll
                for (int mi = 0; mi < MT; ++mi) {
#pragma unroll
                    for (int ni = 0; ni < NT; ++ni) {
                        mma_bf16(accum[mi][ni][0], accum[mi][ni][1], accum[mi][ni][2],
                                 accum[mi][ni][3], a_frag[mi][0], a_frag[mi][1], a_frag[mi][2],
                                 a_frag[mi][3], b_frag[ni][0], b_frag[ni][1]);
                    }
                }
            }
        }

        __syncthreads();
        if constexpr (BS == S) {
            const int prefetch_tile = k_tile + S;
            if (prefetch_tile < k_tiles) { stage_inputs(stage, prefetch_tile); }
            cp_commit();
        } else {
            const int next_tile = k_tile + 1;
            if (next_tile < k_tiles) { stage_activation(0, next_tile); }
            cp_commit();
        }
    }

#pragma unroll
    for (int mi = 0; mi < MT; ++mi) {
        const int output_row0 = row0 + warp_row * WM + mi * 16 + mma_row;
        const int output_row1 = output_row0 + 8;
#pragma unroll
        for (int ni = 0; ni < NT; ++ni) {
            const int output_col0 = col0 + warp_col * WN + ni * 8 + 2 * mma_col;
            const int output_col1 = output_col0 + 1;
            const float* values   = accum[mi][ni];
            if constexpr (kFull) {
                out[static_cast<std::int64_t>(output_col0) * rows + output_row0] =
                    __float2bfloat16_rn(values[0]);
                out[static_cast<std::int64_t>(output_col1) * rows + output_row0] =
                    __float2bfloat16_rn(values[1]);
                out[static_cast<std::int64_t>(output_col0) * rows + output_row1] =
                    __float2bfloat16_rn(values[2]);
                out[static_cast<std::int64_t>(output_col1) * rows + output_row1] =
                    __float2bfloat16_rn(values[3]);
            } else {
                if (output_row0 < rows) {
                    if (output_col0 < cols) {
                        out[static_cast<std::int64_t>(output_col0) * rows + output_row0] =
                            __float2bfloat16_rn(values[0]);
                    }
                    if (output_col1 < cols) {
                        out[static_cast<std::int64_t>(output_col1) * rows + output_row0] =
                            __float2bfloat16_rn(values[1]);
                    }
                }
                if (output_row1 < rows) {
                    if (output_col0 < cols) {
                        out[static_cast<std::int64_t>(output_col0) * rows + output_row1] =
                            __float2bfloat16_rn(values[2]);
                    }
                    if (output_col1 < cols) {
                        out[static_cast<std::int64_t>(output_col1) * rows + output_row1] =
                            __float2bfloat16_rn(values[3]);
                    }
                }
            }
        }
    }
}

} // namespace ninfer::ops::detail
