#pragma once
// Autonomous private S4/H512/G512 probe, parent C128 layout; never a production dispatch.
// Paired H512/G512 W4/A4,10 exactS32 groups, ascendingFP32FMA, plain projection oneBF16 into query/key/gate/value.
#include "ops/common/math.cuh"
#include "ops/common/mma.cuh"
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <stdexcept>

namespace ucloud2::attention_input_s4h512 {
using ninfer::ops::cp_commit;
using ninfer::ops::cp_wait;
using ninfer::ops::ldmatrix_x4;

using ninfer::ops::smem_addr;
constexpr int K=5120, N=14336, Groups=10;
constexpr int Rows=128, Tokens=128, StepK=128, StepBytes=64, Threads=256, Steps=40;
constexpr int OutRows=128, OutLd=136, MT=4;
struct Output { __nv_bfloat16 *q,*key,*gate,*value; };
struct alignas(128) Stage { std::uint8_t w[Rows*StepBytes]; std::uint8_t x[Tokens*StepBytes]; };
struct alignas(128) Shared { Stage stage[2]; float ws[Groups*Rows]; float xs[Groups*Tokens]; uint8_t output_pad[8192]; };
constexpr std::size_t SharedBytes=sizeof(Shared);
static_assert(sizeof(Stage)==16384 && SharedBytes==51200);
static_assert(offsetof(Shared,ws)==32768 && offsetof(Shared,xs)==37888);
static_assert(sizeof(Stage)+Tokens*OutLd*sizeof(__nv_bfloat16)<=SharedBytes);
static_assert(std::int64_t(K)*7*7<INT32_MAX);

__host__ __device__ constexpr int weight_row(int block,int local) {
    return block*Rows+local;
}
__host__ __device__ constexpr unsigned swizzled(int line,int chunk) {
    return unsigned(line*StepBytes+((chunk^((line>>1)&3))<<4));
}

__device__ __forceinline__ void mma_s4(int& d0,int& d1,int& d2,int& d3,unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned b0,unsigned b1){
 asm volatile("mma.sync.aligned.m16n8k64.row.col.s32.s4.s4.s32 {%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};\n":"+r"(d0),"+r"(d1),"+r"(d2),"+r"(d3):"r"(a0),"r"(a1),"r"(a2),"r"(a3),"r"(b0),"r"(b1));
}

// Debug is the same computation plus complete raw-S32 stores. Timing instantiation
// Debug=false has no global raw tensor read or write, and receives raw=nullptr.
template<bool Debug>
__global__ void __launch_bounds__(Threads,1) kernel(
        const std::uint8_t* __restrict__ W, const float* __restrict__ ws,
        const std::uint8_t* __restrict__ X, const float* __restrict__ xs,
        Output output, std::int32_t* __restrict__ raw,
        float* __restrict__ pre,int debug_group,int tokens,int token_tiles,int total_tiles) {
    extern __shared__ __align__(128) std::uint8_t storage[];
    auto& sh=*reinterpret_cast<Shared*>(storage);
    const int tid=int(threadIdx.x),warp=tid>>5,lane=tid&31;
    const int wm=warp%2,wn=warp/2,gid=lane>>2,lid=lane&3;
    const int line0=tid>>2,chunk=tid&3;
    int tile=int(blockIdx.x),row_block=0,token0=0,live=0;
    // Fixed source sizes fit uint32; pointer addition still uses the full GPU pointer.
    std::uint32_t woff[2],xoff[2];
    const auto set_tile=[&](int t) {
        row_block=t/token_tiles;token0=(t%token_tiles)*Tokens;
        live=min(Tokens,tokens-token0);
#pragma unroll
        for(int i=0;i<2;++i){
            int line=line0+i*64;
            woff[i]=std::uint32_t(weight_row(row_block,line)*(K/2)+chunk*16);
            xoff[i]=std::uint32_t((token0+(line<live?line:0))*(K/2)+chunk*16);
        }
    };
    const auto issue_step=[&](int step,Stage& s) {
        const unsigned wbase=smem_addr(s.w)+swizzled(line0,chunk);
        const unsigned xbase=smem_addr(s.x)+swizzled(line0,chunk);
#pragma unroll
        for(int i=0;i<2;++i){
            asm volatile("cp.async.cg.shared.global [%0], [%1], 16;\n"::
                "r"(wbase+i*64*StepBytes),"l"(W+woff[i]+step*StepBytes));
            asm volatile("cp.async.cg.shared.global [%0], [%1], 16, %2;\n"::
                "r"(xbase+i*64*StepBytes),"l"(X+xoff[i]+step*StepBytes),
                "r"(line0+i*64<live?16:0));
        }
    };
    const auto issue_scales=[&] {
        // Group-major shared cache, row-major global scales. All10 groups live
        // through this tile; next-tile scale publication follows the epilogue barrier.
        for(int group=0;group<Groups;++group){
            if(tid<Rows){
                asm volatile("cp.async.ca.shared.global [%0], [%1], 4;\n"::
                    "r"(smem_addr(sh.ws+group*Rows+tid)),"l"(ws+weight_row(row_block,tid)*Groups+group));
            }else{
                int token=tid-Rows;
                asm volatile("cp.async.ca.shared.global [%0], [%1], 4, %2;\n"::
                    "r"(smem_addr(sh.xs+group*Tokens+token)),"l"(xs+(token0+(token<live?token:0))*Groups+group),"r"(token<live?4:0));
            }
        }
    };
    // Same canonical C128 ldmatrix address mapping, packed signed4 operands with64logical K per32bytes.
    const unsigned a_off=unsigned(offsetof(Stage,w))+
        swizzled(wm*64+(lane&7)+((lane>>3)&1)*8,lane>>4);
    const unsigned b_off=unsigned(offsetof(Stage,x))+
        swizzled(wn*32+(lane>>4)*8+(lane&7),(lane>>3)&1);
    set_tile(tile);issue_step(0,sh.stage[0]);issue_scales();cp_commit();
    for(;;){
        int g[MT][4][4]; float f[MT][4][4];
#pragma unroll
        for(int mt=0;mt<MT;++mt)
#pragma unroll
            for(int nt=0;nt<4;++nt)
#pragma unroll
                for(int e=0;e<4;++e){g[mt][nt][e]=0;f[mt][nt][e]=0.f;}
        for(int step=0;step<Steps;++step){
            cp_wait<0>();
            // Publish this stage; all warps also finished the previous stage,
            // which is the destination of step+1's copies.
            __syncthreads();
            if(step+1<Steps){issue_step(step+1,sh.stage[(step+1)&1]);cp_commit();}
            const unsigned base=smem_addr(&sh.stage[step&1]);
#pragma unroll
            for(int ks=0;ks<2;++ks){
                const unsigned slice=unsigned(ks)<<5;
                unsigned b[4][2];
#pragma unroll
                for(int np=0;np<2;++np)
                    ldmatrix_x4(b[2*np][0],b[2*np][1],b[2*np+1][0],b[2*np+1][1],
                        base+(b_off^slice)+np*16*StepBytes);
#pragma unroll
                for(int mt=0;mt<MT;++mt){
                    unsigned a0,a1,a2,a3;
                    ldmatrix_x4(a0,a1,a2,a3,base+(a_off^slice)+mt*16*StepBytes);
#pragma unroll
                    for(int nt=0;nt<4;++nt){int* d=g[mt][nt];
                        mma_s4(d[0],d[1],d[2],d[3],a0,a1,a2,a3,b[nt][0],b[nt][1]);
                    }
                }
            }
            if((step&3)==3){
                const int group=step>>2;
#pragma unroll
                for(int mt=0;mt<MT;++mt)
#pragma unroll
                    for(int nt=0;nt<4;++nt)
#pragma unroll
                        for(int e=0;e<4;++e){
                            int row=wm*64+mt*16+gid+(e>>1)*8;
                            int token=wn*32+nt*8+2*lid+(e&1);
                            if constexpr(Debug)if(group==debug_group&&token<live)
                                raw[std::int64_t(token0+token)*N+weight_row(row_block,row)]=g[mt][nt][e];
                            float unit=__fmul_rn(sh.ws[group*Rows+row],sh.xs[group*Tokens+token]);
                            f[mt][nt][e]=__fmaf_rn(__int2float_rn(g[mt][nt][e]),unit,f[mt][nt][e]);
                            g[mt][nt][e]=0;
                        }
            }
        }
        // All K-stage and scale reads are complete before stage1 + retired ws become BF16 output staging.
        __syncthreads();
        const int out_row_block=row_block,out_token0=token0,out_live=live;
        if constexpr(Debug){
#pragma unroll
            for(int mt=0;mt<MT;++mt)
#pragma unroll
                for(int nt=0;nt<4;++nt)
#pragma unroll
                    for(int e=0;e<4;++e){
                        int row=wm*64+mt*16+gid+(e>>1)*8;
                        int token=wn*32+nt*8+2*lid+(e&1);
                        if(token<out_live)pre[std::int64_t(out_token0+token)*N+
                            weight_row(out_row_block,row)]=f[mt][nt][e];
                    }
        }
        tile+=int(gridDim.x);const bool more=tile<total_tiles;
        if(more){set_tile(tile);issue_step(0,sh.stage[0]);cp_commit();}
        // Next-tile copies touch only stage0. Old scales have retired; output aliases retired ws/xs.
        auto* staged=reinterpret_cast<__nv_bfloat16*>(storage+sizeof(Stage));
#pragma unroll
        for(int mt=0;mt<MT;++mt)
#pragma unroll
            for(int nt=0;nt<4;++nt)
#pragma unroll
                for(int e=0;e<4;++e){
                    const int row=wm*64+mt*16+gid+(e>>1)*8;
                    const int token=wn*32+nt*8+2*lid+(e&1);
                    // Plain projection: one BF16 RN, no residual or intermediate global tensor.
                    staged[token*OutLd+row]=__float2bfloat16_rn(f[mt][nt][e]);
                }
        __syncthreads(); // every old scale read and output staging write is complete
#pragma unroll
        for(int i=0;i<8;++i){
            const int item=tid+i*Threads,token=item/16,chunk_out=item%16;
            const uint4 value=*reinterpret_cast<const uint4*>(staged+token*OutLd+chunk_out*8);
            if(token<out_live){
                const int grow=out_row_block*OutRows+chunk_out*8;
                // Independent query/key/gate/value output buffers, matching the original outputs.
                auto* dst=grow<6144 ? output.q+std::int64_t(out_token0+token)*6144+grow
                    : grow<7168 ? output.key+std::int64_t(out_token0+token)*1024+grow-6144
                    : grow<13312 ? output.gate+std::int64_t(out_token0+token)*6144+grow-7168
                    : output.value+std::int64_t(out_token0+token)*1024+grow-13312;
                *reinterpret_cast<uint4*>(dst)=value;
            }
        }
        // The output staging aliases retired weight and activation scales. All warps must finish
        // their output reads before next-tile scale copies may overwrite them.
        __syncthreads();
        if(!more)break;
        // Output-read barrier above retires its ws alias. Next K-step wait/barrier also protects stage1.
        issue_scales();cp_commit();
    }
}

// Future harness must call once before any cold Graph capture. No hidden first-use setup.
inline cudaError_t prepare_attributes(){
    auto e=cudaFuncSetAttribute(kernel<false>,cudaFuncAttributeMaxDynamicSharedMemorySize,int(SharedBytes));
    if(e!=cudaSuccess)return e;
    return cudaFuncSetAttribute(kernel<true>,cudaFuncAttributeMaxDynamicSharedMemorySize,int(SharedBytes));
}
template<bool Debug>
inline void launch(const std::uint8_t* W,const float* ws,const std::uint8_t* X,const float* xs,
                   Output output,std::int32_t* raw,float* pre,int debug_group,int tokens,int sm_count,cudaStream_t stream){
    if((tokens<1||tokens>2048)||sm_count<=0||(Debug?(raw==nullptr||pre==nullptr||debug_group<0||debug_group>=Groups):(raw!=nullptr||pre!=nullptr)))
        throw std::runtime_error("fixed fused diagnostic shape/pointer contract");
    const int tiles=(tokens+Tokens-1)/Tokens,total=(N/OutRows)*tiles;
    kernel<Debug><<<std::min(total,sm_count),Threads,SharedBytes,stream>>>(W,ws,X,xs,output,raw,pre,debug_group,tokens,tiles,total);
}
} // namespace ucloud2::attention_input_s4h512
