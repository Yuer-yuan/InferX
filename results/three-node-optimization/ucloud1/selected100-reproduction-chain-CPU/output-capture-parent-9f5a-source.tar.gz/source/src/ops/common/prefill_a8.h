#pragma once
#include "core/layout.h"
#include "ops/common/int8_proj_launch.h"
#include <algorithm>
#include <cstdlib>
#include <string_view>

namespace ninfer::ops::detail {
// Experimental precision profile. Target leaves gate this at TextPhase::Prefill.
// Valid values: none (default), swiglu, ffn, all. Never changes small-T decode.
inline bool prefill_a8_enabled(std::string_view route) {
    static const std::string_view mode = [] {
        const char* p = std::getenv("NINFER_PREFILL_A8");
        return std::string_view(p ? p : "none");
    }();
    return mode == "all" || (mode == "ffn" && (route == "swiglu" || route == "down")) ||
           (mode == "swiglu" && route == "swiglu");
}
constexpr std::int32_t q4_linear_swiglu_int8_padded_k(std::int32_t k) noexcept {
    return ((k + 255) / 256) * 256;
}
constexpr std::int32_t q5_linear_add_int8_padded_k(std::int32_t k) noexcept {
    return ((k + 255) / 256) * 256;
}
constexpr std::int32_t q4_linear_swiglu_int8_token_tile(std::int32_t t) noexcept {
    return t < 4096 ? t : 4096;
}
constexpr std::int32_t q5_linear_add_int8_token_tile(std::int32_t t) noexcept {
    return t < 4096 ? t : 4096;
}
using Q4LinearSwiGluInt8Workspace = Int8ProjWorkspace;
using Q5LinearAddInt8Workspace = Int8ProjWorkspace;
template<class Allocator>
inline Int8ProjWorkspace prefill_a8_workspace(Allocator& arena, int k, int cols) {
    const int pk = int8_proj_padded_k(k), tile = int8_proj_token_tile(cols);
    auto codes = arena.alloc_bytes(static_cast<std::size_t>(pk) * tile);
    auto scales = arena.alloc(DType::FP32, {tile, pk / 64});
    return {static_cast<std::int8_t*>(codes.data), static_cast<float*>(scales.data)};
}
inline std::size_t prefill_a8_workspace_bytes(int k, int cols) {
    WorkspaceLayoutBuilder arena;
    (void)prefill_a8_workspace(arena, k, cols);
    return arena.peak_bytes();
}
void q4_linear_swiglu_int8_folded_launch(const Tensor&, const Weight&, Tensor&,
                                        const Q4LinearSwiGluInt8Workspace&, cudaStream_t);
std::int32_t q4_linear_swiglu_int8_block_cols() noexcept;
void q5_linear_add_int8_residual_launch(const Tensor&, const Weight&, Tensor&,
                                        const Q5LinearAddInt8Workspace&, cudaStream_t);
void q4_q5_attn_input_int8_launch(const Tensor&, const Weight&, const Weight&, Tensor&, Tensor&,
                                  Tensor&, Tensor&, const Int8ProjWorkspace&, cudaStream_t);
void q4_q5_gdn_input_int8_launch(const Tensor&, const Weight&, const Weight&, Tensor&, Tensor&,
                                 const Int8ProjWorkspace&, cudaStream_t);
}
