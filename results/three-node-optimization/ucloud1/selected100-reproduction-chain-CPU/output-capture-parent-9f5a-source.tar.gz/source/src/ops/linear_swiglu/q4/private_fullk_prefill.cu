#include "ops/linear_swiglu/q4/private_fullk_prefill.h"
#include "ops/linear_swiglu/q4/private_fullk_c128.cuh"
#include "ops/linear_swiglu/q4/private_fullk_quant.cuh"
#include "core/device.h"
#include "private_gptq_s4.cuh"
#include "private_gptq_h512.cuh"
#include "private_gptq_down_h512.cuh"
#include "private_gptq_down_s4.cuh"
#include <cmath>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <stdexcept>
#include <vector>
namespace ninfer::ops::detail {
bool fullk_s4_enabled(){const char* s=std::getenv("NINFER_PREFILL_FULLK");return s&&!std::strcmp(s,"s4gptq64ffn");}
bool fullk_s4_target_enabled(){
 static const bool enabled=[](){
  const char* s=std::getenv("NINFER_S4_TARGET_FFN");
  if(!s||!std::strcmp(s,"0"))return false;
  if(std::strcmp(s,"1"))throw std::invalid_argument("NINFER_S4_TARGET_FFN supports 0/1");
  if(!fullk_s4_enabled())throw std::invalid_argument("NINFER_S4_TARGET_FFN requires s4gptq64ffn cache");
  return true;
 }();
 return enabled;
}
bool fullk_s4_omit_legacy_enabled(){
 static const bool enabled=[](){
  const char* s=std::getenv("NINFER_S4_OMIT_LEGACY_FFN");
  if(!s||!std::strcmp(s,"0"))return false;
  if(std::strcmp(s,"1"))throw std::invalid_argument("NINFER_S4_OMIT_LEGACY_FFN supports 0/1");
  if(!fullk_s4_target_enabled())throw std::invalid_argument("legacy FFN omission requires target S4");
  return true;
 }();
 return enabled;
}
bool fullk_prefill_enabled(){const char* s=std::getenv("NINFER_PREFILL_FULLK");if(!s||!std::strcmp(s,"off"))return false;if(std::strcmp(s,"c128")&&!fullk_s4_enabled())throw std::invalid_argument("NINFER_PREFILL_FULLK supports off/c128/s4gptq64ffn");return true;}
void fullk_prepare(){if(fullk_s4_enabled()){CUDA_CHECK(ucloud2::group512_s4h512::prepare_attributes());CUDA_CHECK(ucloud2::down_s4h512::prepare_attributes());CUDA_CHECK(cudaFuncSetAttribute(ucloud2::down_h512_quant::kernel,cudaFuncAttributeMaxDynamicSharedMemorySize,70720));}else CUDA_CHECK(ucloud2::fullk_fused::prepare_attributes());(void)ninfer::device_sm_count();}
bool fullk_s4_selected_layer(int layer){return layer>=0&&layer<64;}
void fullk_load_s4_cache(int8_t* q,float* scales,int layer,cudaStream_t stream){
 if(!fullk_s4_selected_layer(layer))throw std::runtime_error("fixed64-layer cache contract");
 const char* dir=std::getenv("NINFER_S4_GPTQ_CACHE");if(!dir||!*dir)throw std::runtime_error("explicit frozen S4 GPTQ cache path required");
 auto load=[&](const char* kind,int8_t* dstq,float* dsts,size_t qbytes,size_t sbytes){
  auto read=[&](const char* name,size_t bytes){auto path=std::filesystem::path(dir)/("weights-L"+std::to_string(layer)+"-"+kind)/name;std::ifstream f(path,std::ios::binary|std::ios::ate);if(!f||f.tellg()!=std::streamoff(bytes))throw std::runtime_error("S4 GPTQ cache size: "+path.string());std::vector<uint8_t> v(bytes);f.seekg(0);f.read(reinterpret_cast<char*>(v.data()),bytes);if(!f)throw std::runtime_error("S4 GPTQ cache read failed");return v;};
  auto codes=read("packed.bin",qbytes);auto raw=read("scales.f32",sbytes);
  for(auto v:codes)if((v&15)==8||(v>>4)==8)throw std::runtime_error("S4 GPTQ invalid -8 code");
  for(size_t i=0;i<raw.size();i+=4){float v;std::memcpy(&v,raw.data()+i,4);if(!(v>0)||!std::isfinite(v))throw std::runtime_error("S4 GPTQ invalid scale");}
  CUDA_CHECK(cudaMemcpyAsync(dstq,codes.data(),qbytes,cudaMemcpyHostToDevice,stream));CUDA_CHECK(cudaMemcpyAsync(dsts,raw.data(),sbytes,cudaMemcpyHostToDevice,stream));CUDA_CHECK(cudaStreamSynchronize(stream));
  std::vector<uint8_t> check(qbytes);CUDA_CHECK(cudaMemcpyAsync(check.data(),dstq,qbytes,cudaMemcpyDeviceToHost,stream));CUDA_CHECK(cudaStreamSynchronize(stream));if(check!=codes)throw std::runtime_error("S4 complete device codes readback mismatch");check.resize(sbytes);CUDA_CHECK(cudaMemcpyAsync(check.data(),dsts,sbytes,cudaMemcpyDeviceToHost,stream));CUDA_CHECK(cudaStreamSynchronize(stream));if(check!=raw)throw std::runtime_error("S4 complete device scales readback mismatch");
 };
 if(reinterpret_cast<uint8_t*>(scales)!=reinterpret_cast<uint8_t*>(q)+s4_gate_codes)throw std::runtime_error("S4 fixed perlayer pointer layout");
 load("gate",q,scales,s4_gate_codes,s4_gate_scales);
 auto* downq=reinterpret_cast<int8_t*>(reinterpret_cast<uint8_t*>(scales)+s4_gate_scales);auto* downs=reinterpret_cast<float*>(downq+s4_down_codes);
 load("down",downq,downs,s4_down_codes,s4_down_scales);
 std::fprintf(stderr,"S4_complete_cache_readback layer=%d gate_bytes=%zu down_bytes=%zu full_code_scale_bitexact=1\n",layer,s4_gate_codes+s4_gate_scales,s4_down_codes+s4_down_scales);

}
void fullk_build_cache(const Weight& w,int8_t* q,float* scales,int* invalid,cudaStream_t stream){
 if(w.qtype!=QType::Q4G64_F16S||w.padded_shape[0]!=34816||w.padded_shape[1]!=5120)throw std::invalid_argument("fullK cache requires original Q4G64 34816x5120");
 fullk_private::build_cache<<<34816,256,0,stream>>>(static_cast<const uint8_t*>(w.qdata),static_cast<const __half*>(w.scales),q,scales,invalid);CUDA_CHECK(cudaGetLastError());
}
void fullk_gate_launch(const Tensor& x,const FullKGateView& w,Tensor& y,const Int8ProjWorkspace& scratch,cudaStream_t stream){
 const int t=x.ne[1];if(!w.codes||!w.scales||x.ne[0]!=5120||y.ne[0]!=17408||(t<(fullk_s4_enabled()?1:256)||t>2048))throw std::invalid_argument("fullK qualified shape contract");
 if(fullk_s4_enabled()){
  if(!fullk_s4_selected_layer(w.layer))throw std::runtime_error("S4 GPTQ selected layer contract");
  ucloud2::h512_quant::kernel<<<t,256,0,stream>>>(static_cast<const __nv_bfloat16*>(x.data),reinterpret_cast<uint8_t*>(scratch.codes),scratch.scales,nullptr,t);CUDA_CHECK(cudaGetLastError());
  ucloud2::group512_s4h512::launch<false>(reinterpret_cast<const uint8_t*>(w.codes),w.scales,reinterpret_cast<const uint8_t*>(scratch.codes),scratch.scales,static_cast<__nv_bfloat16*>(y.data),nullptr,nullptr,0,t,ninfer::device_sm_count(),stream);CUDA_CHECK(cudaGetLastError());
  static const bool log=std::getenv("NINFER_S4_ROUTE_LOG")!=nullptr;if(log)std::fprintf(stderr,"UCLOUD2_S4_ROUTE layer=%d scope=target_ffn T=%d K=5120 N=34816 cache=%p stream=%p\n",w.layer,t,static_cast<const void*>(w.codes),static_cast<void*>(stream));
  return;
 }
 fullk_private::fullk_token_quant<<<t,256,0,stream>>>(static_cast<const __nv_bfloat16*>(x.data),scratch.codes,scratch.scales,t);CUDA_CHECK(cudaGetLastError());
 ucloud2::fullk_fused::launch<false>(w.codes,w.scales,scratch.codes,scratch.scales,static_cast<__nv_bfloat16*>(y.data),nullptr,t,ninfer::device_sm_count(),stream);CUDA_CHECK(cudaGetLastError());
}
void fullk_down_launch(const Tensor& x,const FullKGateView& w,Tensor& residual,const Int8ProjWorkspace& scratch,cudaStream_t stream){
 const int t=x.ne[1];if(!fullk_s4_enabled()||!w.codes||!w.scales||!fullk_s4_selected_layer(w.layer)||x.ne[0]!=17408||residual.ne[0]!=5120||residual.ne[1]!=t||t<1||t>2048)throw std::invalid_argument("S4 down fixed profile contract");
 const auto* q=reinterpret_cast<const uint8_t*>(w.scales)+s4_gate_scales;const auto* scales=reinterpret_cast<const float*>(q+s4_down_codes);
 ucloud2::down_h512_quant::kernel<<<t,256,70720,stream>>>(static_cast<const __nv_bfloat16*>(x.data),reinterpret_cast<uint8_t*>(scratch.codes),scratch.scales,nullptr,t);CUDA_CHECK(cudaGetLastError());
 ucloud2::down_s4h512::launch<false>(q,scales,reinterpret_cast<const uint8_t*>(scratch.codes),scratch.scales,static_cast<__nv_bfloat16*>(residual.data),nullptr,nullptr,0,t,ninfer::device_sm_count(),stream);CUDA_CHECK(cudaGetLastError());
 static const bool log=std::getenv("NINFER_S4_ROUTE_LOG")!=nullptr;if(log)std::fprintf(stderr,"UCLOUD2_S4_DOWN_ROUTE layer=%d scope=target_ffn T=%d K=17408 N=5120 cache=%p stream=%p\n",w.layer,t,static_cast<const void*>(q),static_cast<void*>(stream));
}
void fullk_capture_down(const Tensor& x,const Tensor& residual,int layer,bool before,cudaStream_t stream){
 static const char* dir=std::getenv("NINFER_FULLK_CAPTURE_DIR");if(!dir||!*dir||(layer!=0&&layer!=31&&layer!=61&&layer!=63)||x.ne[1]!=2048)return;
 static std::mutex lock;static std::array<bool,64> seen{};std::lock_guard guard(lock);if(seen[layer])return;
 if(x.ne[0]!=17408||residual.ne[0]!=5120||residual.ne[1]!=2048)throw std::runtime_error("down capture shape");
 CUDA_CHECK(cudaStreamSynchronize(stream));std::filesystem::path root(dir);std::filesystem::create_directories(root);
 auto save=[&](const char* suffix,const void* device,size_t bytes){std::vector<uint8_t> host(bytes);CUDA_CHECK(cudaMemcpyAsync(host.data(),device,bytes,cudaMemcpyDeviceToHost,stream));CUDA_CHECK(cudaStreamSynchronize(stream));auto p=root/("layer-"+std::to_string(layer)+suffix);if(std::filesystem::exists(p))throw std::runtime_error("down capture path already exists");std::ofstream f(p,std::ios::binary);f.write(reinterpret_cast<const char*>(host.data()),bytes);if(!f)throw std::runtime_error("down capture write failed");};
 if(before){save("-down-X-T2048.bf16",x.data,size_t(2048)*17408*2);save("-down-Rbefore-T2048.bf16",residual.data,size_t(2048)*5120*2);}else{save("-down-Y-T2048.bf16",residual.data,size_t(2048)*5120*2);seen[layer]=true;}
}
void fullk_capture_actual(const Tensor& x,const Tensor& y,const Weight& w,int layer,cudaStream_t stream){
 static const bool route=std::getenv("NINFER_S4_ROUTE_LOG")!=nullptr;if(route&&fullk_s4_selected_layer(layer))std::fprintf(stderr,"UCLOUD2_PREFILL_ROUTE layer=%d T=%lld candidate=%d\n",layer,static_cast<long long>(x.ne[1]),int(fullk_s4_enabled()&&(x.ne[1]>=256&&x.ne[1]<=2048)));
 static const char* dir=std::getenv("NINFER_FULLK_CAPTURE_DIR");if(!dir||!*dir||(layer!=0&&layer!=31&&layer!=61&&layer!=63)||x.ne[1]!=2048)return;
 static std::mutex lock;static std::array<bool,64> seen{};std::lock_guard guard(lock);if(seen[layer])return;
 CUDA_CHECK(cudaStreamSynchronize(stream));std::filesystem::path root(dir);std::filesystem::create_directories(root);
 auto save=[&](const char* suffix,const void* device,size_t bytes){std::vector<uint8_t> host(bytes);CUDA_CHECK(cudaMemcpyAsync(host.data(),device,bytes,cudaMemcpyDeviceToHost,stream));CUDA_CHECK(cudaStreamSynchronize(stream));auto p=root/("layer-"+std::to_string(layer)+suffix);if(std::filesystem::exists(p))throw std::runtime_error("capture path already exists");std::ofstream f(p,std::ios::binary);f.write(reinterpret_cast<const char*>(host.data()),bytes);if(!f)throw std::runtime_error("capture write failed");};
 save("-X-T2048.bf16",x.data,size_t(2048)*5120*2);save("-Y-T2048.bf16",y.data,size_t(2048)*17408*2);save("-packed-prefix256.bin",w.qdata,256);save("-scale-prefix256.bin",w.scales,256);seen[layer]=true;
 std::fprintf(stderr,"fullK_actual_capture layer=%d T=2048 K=5120 N=34816 candidate=%d\n",layer,int(fullk_prefill_enabled()));
}
}
