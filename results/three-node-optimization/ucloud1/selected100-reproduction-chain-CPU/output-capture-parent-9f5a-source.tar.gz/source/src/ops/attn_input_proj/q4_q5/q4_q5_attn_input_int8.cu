#include "ops/common/prefill_a8.h"
#include "ops/common/jg_grouped_pipeline.cuh"
#include <array>
namespace ninfer::ops::detail {
void q4_q5_attn_input_int8_launch(const Tensor& x,const Weight& w0,const Weight& w1,Tensor& q,Tensor& gate,Tensor& k,Tensor& v,const Int8ProjWorkspace& scratch,cudaStream_t stream) {std::array<Tensor,4> out{q,gate,k,v};jg_grouped_launch(x,w0,w1,std::span<Tensor>(out),scratch,stream,true);}
}
