#include "private_input_s4.h"
#include "private_input_gdn_s4.cuh"
#include "private_input_attention_s4.cuh"
#include "private_input_h512.cuh"
#include "core/device.h"
#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <unordered_map>
#include <vector>
namespace ninfer::ops::detail {
namespace {
struct View {const std::uint8_t* codes;const float* scales;int layer;};
std::unordered_map<const void*,View> views;
bool begun=false,sealed=false;
void shape(const Tensor& x,int rows,int T){if(x.ne[0]!=rows||x.ne[1]!=T||x.nb[0]!=2||x.nb[1]!=rows*2)throw std::runtime_error("inputS4 contiguous BF16 tensor contract");}
const View& get(const Weight& w,bool attention){
 if(!sealed)throw std::runtime_error("inputS4 registry must be sealed before Graph/runtime");
 const auto& registry=views;auto it=registry.find(w.qdata);
 if(it==registry.end()||((it->second.layer+1)%4==0)!=attention)throw std::runtime_error("inputS4 registered original projection mismatch");
 return it->second;
}
void quant(const Tensor& x,const Int8ProjWorkspace& scratch,cudaStream_t stream){
 ucloud2::input_h512_quant::kernel<<<int(x.ne[1]),256,0,stream>>>(static_cast<const __nv_bfloat16*>(x.data),reinterpret_cast<std::uint8_t*>(scratch.codes),scratch.scales,nullptr,int(x.ne[1]));CUDA_CHECK(cudaGetLastError());
}
void route(const View& v,int T,const char* kind,const void* p0,const void* p1,cudaStream_t s){
 static const bool log=std::getenv("NINFER_INPUT_S4_ROUTE_LOG")!=nullptr;
 if(log)std::fprintf(stderr,"UCLOUD2_INPUT_S4_ROUTE layer=%d kind=%s phase=Prefill T=%d K=5120 H=512 group=512 out0=%p out1=%p cache=%p stream=%p\n",v.layer,kind,T,p0,p1,v.codes,static_cast<void*>(s));
}
}
bool input_s4_enabled(){const char* s=std::getenv("NINFER_INPUT_S4");return s&&!std::strcmp(s,"1");}
void input_s4_begin(){
 if(begun)throw std::runtime_error("private inputS4 supports one model lifetime per process");
 begun=true;views.reserve(64);
 CUDA_CHECK(ucloud2::input_s4h512::prepare_attributes());CUDA_CHECK(ucloud2::attention_input_s4h512::prepare_attributes());(void)ninfer::device_sm_count();
}
void input_s4_load_register(const Weight& original,std::uint8_t* cache,int layer,cudaStream_t stream){
 if(!begun||sealed||layer<0||layer>=64||original.qtype!=QType::Q4G64_F16S||original.padded_shape[0]!=((layer+1)%4==0?7168:4096)||original.padded_shape[1]!=5120)throw std::runtime_error("inputS4 fixed layer/source registration contract");
 const char* dir=std::getenv("NINFER_INPUT_S4_CACHE");if(!dir||!*dir)throw std::runtime_error("explicit frozen041 input cache path required");
 const std::size_t qb=input_s4_codes(layer),sb=input_s4_scales(layer);
 auto read=[&](const char* name,std::size_t size){auto p=std::filesystem::path(dir)/("weights-L"+std::to_string(layer)+"-input")/name;std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f||f.tellg()!=std::streamoff(size))throw std::runtime_error("inputS4 frozen file size "+p.string());std::vector<std::uint8_t> v(size);f.seekg(0);f.read(reinterpret_cast<char*>(v.data()),size);if(!f)throw std::runtime_error("inputS4 file read");return v;};
 auto q=read("packed.bin",qb),s=read("scales.f32",sb);
 for(auto v:q)if((v&15)==8||(v>>4)==8)throw std::runtime_error("invalid -8 inputS4 code");
 for(std::size_t i=0;i<s.size();i+=4){float v;std::memcpy(&v,s.data()+i,4);if(!(v>0)||!std::isfinite(v))throw std::runtime_error("invalid inputS4 scale");}
 CUDA_CHECK(cudaMemcpyAsync(cache,q.data(),qb,cudaMemcpyHostToDevice,stream));CUDA_CHECK(cudaMemcpyAsync(cache+qb,s.data(),sb,cudaMemcpyHostToDevice,stream));CUDA_CHECK(cudaStreamSynchronize(stream));
 std::vector<std::uint8_t> check(qb);CUDA_CHECK(cudaMemcpyAsync(check.data(),cache,qb,cudaMemcpyDeviceToHost,stream));CUDA_CHECK(cudaStreamSynchronize(stream));if(check!=q)throw std::runtime_error("inputS4 complete device code readback");check.resize(sb);CUDA_CHECK(cudaMemcpyAsync(check.data(),cache+qb,sb,cudaMemcpyDeviceToHost,stream));CUDA_CHECK(cudaStreamSynchronize(stream));if(check!=s)throw std::runtime_error("inputS4 complete device scale readback");
 if(!views.emplace(original.qdata,View{cache,reinterpret_cast<const float*>(cache+qb),layer}).second)throw std::runtime_error("inputS4 duplicate original pointer");
 std::fprintf(stderr,"INPUT_S4_complete_cache_readback layer=%d codes_bytes=%zu scales_bytes=%zu full_bitexact=1\n",layer,qb,sb);
}
void input_s4_seal(){if(!begun||sealed||views.size()!=64)throw std::runtime_error("inputS4 requires exactly64 registrations");sealed=true;}
bool input_s4_gdn(const Tensor& x,const Weight& w,Tensor& qkv,Tensor& z,const Int8ProjWorkspace& scratch,cudaStream_t stream){
 int T=int(x.ne[1]);if(!input_s4_enabled()||T<1||T>2048)return false;
 shape(x,5120,T);shape(qkv,10240,T);shape(z,6144,T);const auto& v=get(w,false);quant(x,scratch,stream);
 ucloud2::input_s4h512::launch<false>(v.codes,v.scales,reinterpret_cast<const std::uint8_t*>(scratch.codes),scratch.scales,{static_cast<__nv_bfloat16*>(qkv.data),static_cast<__nv_bfloat16*>(z.data)},nullptr,nullptr,0,T,ninfer::device_sm_count(),stream);CUDA_CHECK(cudaGetLastError());route(v,T,"gdn",qkv.data,z.data,stream);return true;
}
bool input_s4_attention(const Tensor& x,const Weight& w,Tensor& query,Tensor& gate,Tensor& key,Tensor& value,const Int8ProjWorkspace& scratch,cudaStream_t stream){
 int T=int(x.ne[1]);if(!input_s4_enabled()||T<1||T>2048)return false;
 shape(x,5120,T);shape(query,6144,T);shape(gate,6144,T);shape(key,1024,T);shape(value,1024,T);const auto& v=get(w,true);quant(x,scratch,stream);
 ucloud2::attention_input_s4h512::launch<false>(v.codes,v.scales,reinterpret_cast<const std::uint8_t*>(scratch.codes),scratch.scales,{static_cast<__nv_bfloat16*>(query.data),static_cast<__nv_bfloat16*>(key.data),static_cast<__nv_bfloat16*>(gate.data),static_cast<__nv_bfloat16*>(value.data)},nullptr,nullptr,0,T,ninfer::device_sm_count(),stream);CUDA_CHECK(cudaGetLastError());route(v,T,"attention",query.data,gate.data,stream);return true;
}
}
