#pragma once
#include "ops/common/mma.cuh"
namespace ninfer::ops::detail {
// v1 lacks the community helper with an explicit initial C operand.
__device__ __forceinline__ void mma_s8_from(int& d0,int& d1,int& d2,int& d3,
 unsigned a0,unsigned a1,unsigned a2,unsigned a3,unsigned b0,unsigned b1,
 int c0,int c1,int c2,int c3) {
 asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 "
              "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%10,%11,%12,%13};\n"
              : "=r"(d0),"=r"(d1),"=r"(d2),"=r"(d3)
              : "r"(a0),"r"(a1),"r"(a2),"r"(a3),"r"(b0),"r"(b1),
                "r"(c0),"r"(c1),"r"(c2),"r"(c3));
}
}
#include "ops/common/rowsplit_tall_a8_mma.cuh"
#include "ops/common/act_quant_g64.h"
namespace ninfer::ops::detail {
// Preserve v1 BF16(residual + FP32projection), with no intermediate BF16 cast.
struct V1ResidualProblem : rowsplit_tall::ResidualQ5Problem {
 template<int MT> __device__ void stage_outputs_at(const float (&acc)[MT][4][4],
  __nv_bfloat16* staged,int ld,int warp_row,int warp_token,int lane,
  int row_block,int token0,int live) const {
#pragma unroll
  for(int mt=0;mt<MT;++mt) {
#pragma unroll
   for(int nt=0;nt<4;++nt) {
    const int r=warp_row+mt*16+(lane>>2),t=warp_token+nt*8+2*(lane&3);
    rowsplit_tall::stage_fragment(staged,ld,r,t,[&](int e) {
     const int token=token0+t+(e&1),row=row_block*128+r+(e>=2?8:0);
     const float residual=token<token0+live?__bfloat162float(out[static_cast<std::int64_t>(token)*rows+row]):0.f;
     return __float2bfloat16_rn(acc[mt][nt][e]+residual);
    });
   }
  }
 }
 __device__ void write(int row_block,int token,int row,uint4 values) const {
  *reinterpret_cast<uint4*>(out+static_cast<std::int64_t>(token)*rows+row_block*128+row)=values;
 }
};
inline void jg_launch(const Tensor& x,const Weight& w,Tensor& out,
 const Int8ProjWorkspace& scratch,cudaStream_t stream,bool sw,bool persistent) {
 const int k=x.ne[0],n=out.ne[0];
 if(k!=w.padded_shape[1] || k%256 || (sw?n%64:n%128))throw std::invalid_argument("JG probe unsupported shape");
 for(int offset=0;offset<x.ne[1];offset+=4096) {
  const int t=std::min(4096,x.ne[1]-offset);const Tensor xs=x.slice(1,offset,t);Tensor os=out.slice(1,offset,t);
  act_quant_g64_launch(static_cast<const __nv_bfloat16*>(xs.data),scratch.codes,scratch.scales,k,t,k,stream);
  if(sw) {
   rowsplit_tall::SwiGluQ4Problem p{static_cast<const std::uint8_t*>(w.qdata),static_cast<const std::uint8_t*>(w.scales),static_cast<__nv_bfloat16*>(os.data),n};
   if(persistent)rowsplit_tall_a8::launch<128,true>(p,n/64,scratch.codes,scratch.scales,k,t,stream);
   else rowsplit_tall_a8::launch<128,false>(p,n/64,scratch.codes,scratch.scales,k,t,stream);
  } else {
   V1ResidualProblem p;p.codes=static_cast<const std::uint8_t*>(w.qdata);p.high=static_cast<const std::uint8_t*>(w.qhigh);p.scales=static_cast<const std::uint8_t*>(w.scales);p.out=static_cast<__nv_bfloat16*>(os.data);p.rows=n;
   const auto waves=[&](int tile){return ((n/128)*((t+tile-1)/tile)+device_sm_count()-1)/device_sm_count();};
   // Same 64/128 rule in both modes, so persistent impact is isolated at 128.
   if(waves(128)*1.55<waves(64)) {
    if(persistent)rowsplit_tall_a8::launch<128,true>(p,n/128,scratch.codes,scratch.scales,k,t,stream);
    else rowsplit_tall_a8::launch<128,false>(p,n/128,scratch.codes,scratch.scales,k,t,stream);
   } else rowsplit_tall_a8::launch<64,false>(p,n/128,scratch.codes,scratch.scales,k,t,stream);
  }
 }
}
}
