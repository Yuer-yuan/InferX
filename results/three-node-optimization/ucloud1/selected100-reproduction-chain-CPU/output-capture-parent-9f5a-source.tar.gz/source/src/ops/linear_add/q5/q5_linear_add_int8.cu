#include "ops/common/prefill_a8.h"
#include "ops/common/jg_pipeline_adapter.cuh"
namespace ninfer::ops::detail {
void q5_linear_add_int8_residual_launch(const Tensor& x,const Weight& w,Tensor& out,const Q5LinearAddInt8Workspace& scratch,cudaStream_t stream) { jg_launch(x,w,out,scratch,stream,false,false); }
}
