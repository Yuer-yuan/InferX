#include <tvm/ffi/container/tensor.h>
#include <tvm/ffi/dtype.h>
#include <tvm/ffi/error.h>
#include <tvm/ffi/extra/c_env_api.h>
#include <tvm/ffi/function.h>
#include "/home/guokc/mypro/gnn-mount-sda1/InferX/sota-validation/builds/marlin-morphx-v2/csrc/gemm/marlin/gptq_marlin.cuh"
namespace sglang {
TVM_FFI_DLL_EXPORT_TYPED_FUNC(gptq_marlin_gemm, (gptq_marlin_gemm<bf16_t>));
}  // namespace sglang
