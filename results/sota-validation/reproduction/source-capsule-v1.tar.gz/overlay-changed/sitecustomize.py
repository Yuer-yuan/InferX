import os
if os.environ.get('INFERX_MORPHX_COMPILE')=='1':
    try:
        from pathlib import Path
        from inferx.morphx_triton import install
        root=Path(os.environ['INFERX_ROOT'])
        install(root/'pd-baselines/builds/morphx-pass-finish-barrier/libsmsched.so','/usr/bin/opt-18',Path(os.environ['INFERX_MORPHX_IR'])/str(os.getpid()))
        print('MORPHX_TRITON_INSTALLED pid='+str(os.getpid()),flush=True)
    except BaseException:
        import traceback
        traceback.print_exc()
        os._exit(78)
